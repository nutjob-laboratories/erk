#
#  Erk IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore

from erk.resources import *
from erk.config import *
import erk.events

class Window(QMainWindow):

	def closeEvent(self, event):
		erk.events.closeMOTDWindow(self.client)
		self.subwindow.close()
		self.close()
		event.accept()

	def write(self,line):

		self.textDisplay.append(line)
		self.textDisplay.moveCursor(QTextCursor.Start)
		self.show()

	def clear(self):
		self.textDisplay.clear()

	def contents(self):
		return self.textDisplay.toPlainText()

	def __init__(self,name,window_margin,subwindow,client,parent=None):
		super(Window, self).__init__(parent)

		self.name = name
		self.subwindow = subwindow
		self.client = client
		self.gui = parent

		self.server = name

		self.linecolor = 0

		self.setWindowTitle(" "+self.name)
		self.setWindowIcon(QIcon(TEXT_WINDOW_ICON))

		self.textDisplay = QTextBrowser(self)
		self.textDisplay.setObjectName("textDisplay")
		self.textDisplay.setStyleSheet(self.gui.styles[BASE_STYLE_NAME])

		self.setCentralWidget(self.textDisplay)

		