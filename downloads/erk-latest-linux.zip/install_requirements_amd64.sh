#!/bin/sh

sudo apt-get install ./requirements/amd64/python3-pyqt5_5.15.2+dfsg-3_amd64.deb ./requirements/python3-twisted_20.3.0-4_all.deb ./requirements/python3-qt5reactor_0.6.1-1_all.deb
