<p align="center">
	<img src="https://github.com/nutjob-laboratories/erk/raw/master/downloads/images/logo.png"><br>
	<img src="https://github.com/nutjob-laboratories/erk/raw/master/downloads/images/nutjob.png"><br>
	<a href="https://github.com/nutjob-laboratories/erk/raw/master/downloads/erk-0.410-unstable.zip">Download Erk 0.410</a><br>
</p>

# Erk

An open source IRC client.