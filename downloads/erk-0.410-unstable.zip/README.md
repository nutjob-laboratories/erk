# erk
Erk is a GUI IRC client written in Python 3, Qt 5, and Twisted.
