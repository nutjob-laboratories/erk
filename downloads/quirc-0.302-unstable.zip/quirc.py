#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import os
import argparse

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

app = QApplication(sys.argv)

import qt5reactor
qt5reactor.install()

from twisted.internet import reactor

from quirc.gui.main import QuricGUI
from quirc.common import *

INSTALLED_STYLES = QStyleFactory.keys()
STYLE_LIST = '"'+ '", "'.join(INSTALLED_STYLES) + '"'

defaults = get_user()

parser = argparse.ArgumentParser(
	prog=f"python {PROGRAM_FILENAME}",
	formatter_class=argparse.RawDescriptionHelpFormatter,
	description=f"{APPLICATION_NAME} {APPLICATION_VERSION} Graphical IRC Client",
	epilog=f"""Available window styles: {STYLE_LIST}
Default window style: \"Windows\"
Default heartbeat interval: 120
Default nickname: \"{defaults['nick']}\"
Default alternate: \"{defaults['alternate']}\"""",
)

parser.add_argument("-t", "--top", help=f"{APPLICATION_NAME}'s window is always on top", action="store_true")
parser.add_argument("-n", "--nossl", help=f"Disable SSL", action="store_true")
parser.add_argument("-f", "--fullscreen", help=f"Displays in full screen mode", action="store_true")
parser.add_argument("-P","--path", type=str, help="Adds a directory to the path", action="append")
parser.add_argument("-w","--window", type=str,help="Selects a window style", default="Windows")
parser.add_argument("-i","--interval", type=int,help="Keep-alive heartbeat interval (seconds)", default=120)


parser.add_argument("-s","--server", type=str,help="Connect to server on startup")
parser.add_argument("-p","--port", type=int,help="Server port",default=6667)
parser.add_argument("-x","--password", type=str,help="Server password",default=None)
parser.add_argument("-S", "--ssl", help="Connect via SSL", action="store_true")


parser.add_argument("-N","--nick", type=str,help="Set default nickname")
parser.add_argument("-a","--alternate", type=str,help="Set default alternate nickname")
parser.add_argument("-u","--username", type=str,help="Set default username")
parser.add_argument("-r","--realname", type=str,help="Set default realname")

parser.add_argument("-e", "--editor", help=f"Opens QuircEdit", action="store_true")
parser.add_argument("-o","--open", type=str,help="Open file in QuircEdit",default=None)

args = parser.parse_args()

if args.path:
	for d in args.path:
		if os.path.isdir(d):
			sys.path.append(d)
		else:
			print("Error adding directory to path!")
			print(f"\"{d}\" doesn't exist or is not a directory.")
			sys.exit(1)

if not args.window in INSTALLED_STYLES:
	print(f"\"{args.window}\" is not a valid style.")
	sys.exit(1)

if __name__ == '__main__':

	app = QApplication([])
	app.setStyle(args.window)

	quircClient = QuricGUI(app)

	if args.top:
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowStaysOnTopHint)
	quircClient.heartbeatInterval = args.interval

	if args.nossl:
		quircClient.can_use_ssl = False

	if args.fullscreen:
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowCloseButtonHint)
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowType_Mask)
		quircClient.showFullScreen()

	user = get_user()
	
	changed = False
	if args.nick:
		user["nick"] = args.nick
		changed = True
	if args.username:
		user["username"] = args.username
		changed = True
	if args.realname:
		user["realname"] = args.realname
		changed = True
	if args.alternate:
		user["alternate"] = args.alternate
		changed = True

	if changed: save_user(user)

	nickname = user["nick"]
	alternate = user["alternate"]
	username = user["username"]
	realname = user["realname"]

	if args.server:
		port = args.port
		ci = [nickname,username,realname,alternate,args.server,str(args.port),args.password,args.ssl]
		quircClient.connectToIRC(ci)

	if args.editor:
		quircClient.newEditorWindowMaximized()

	if args.open:
		quircClient.newEditorWindowFileMaximized(args.open)

	quircClient.show()

	reactor.run()
