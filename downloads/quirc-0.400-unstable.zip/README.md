<p align="center">
	<img src="https://github.com/nutjob-laboratories/quirc/raw/master/downloads/images/quirc-300x133.png"><br>
	<img src="https://github.com/nutjob-laboratories/quirc/raw/master/downloads/images/nutjob.png"><br>
	<a href="https://github.com/nutjob-laboratories/quirc/raw/master/downloads/quirc-0.400-unstable.zip">Download Quirc 0.400</a><br>
	<a href="https://github.com/nutjob-laboratories/quirc/raw/master/documentation/Quirc-Plugin-Guide.pdf">Plugin Documentation</a><br>
	<a href="https://github.com/nutjob-laboratories/quirc-plugins">Plugin Repository</a><br>
</p>

## Summary

**Quirc** is a graphical open source [Internet relay chat](https://en.wikipedia.org/wiki/Internet_Relay_Chat) client. The current development version is **0.400**.

**Quirc** is being actively developed. Although it is missing some features, it is functional at the moment, and can be used for chatting.

**Quirc** is pronounced /kwərk/, just like the word [quirk](https://www.dictionary.com/browse/quirk).

## Features

<p align="center">
	<a href="https://github.com/nutjob-laboratories/quirc/raw/master/downloads/images/screenshot_full.png"><img src="https://github.com/nutjob-laboratories/quirc/raw/master/downloads/images/screenshot.png"></a><br>
	<i>Quirc's interface</i>
</p>

* Supports multiple connections (you can chat on more than one IRC server at a time)
* Uses a [multiple document interface](https://en.wikipedia.org/wiki/Multiple_document_interface) (similar to [mIRC](https://www.mirc.com/))
* Automatic channel and private message logging
* A powerful plugin architecture (plugins are written in Python3, just like Quirc)
* A built-in code editor
* Open source ([GPL 3](https://www.gnu.org/licenses/gpl-3.0.en.html))
* Extensive commandline configuration options
* Built-in spell checker
* Command/nick/channel auto-completion
* Powerful theme engine using QSS and JSON

## Requirements
**Quirc** requires Python 3, Qt5, Twisted, and qt5reactor. Qt5 and Twisted can be installed by downloading and installing the software from their respected websites, or by using [**pip**](https://pypi.org/project/pip/):

    pip install pyqt5
    pip install Twisted
    pip install qt5reactor

To connect to IRC servers via SSL, two additional libraries are needed:

    pip install pyOpenSSL
    pip install service_identity

**Quirc** is being developed with Python 3.7.

## Developing **Quirc**

Note: *All development for **Quirc** is done on Windows. There is no reason why it shouldn't run on any non-Windows operating system, but this is untested. All scripts included for development will run only on Windows, by design.*

The batch file in the root directory, `compile_resources.bat`, bundles all the images in `/resources` into a single file, `/quirc/resources.py`.

The official **Quirc** repository is on [GitHub](https://github.com/nutjob-laboratories/quirc).

## Plugins

If you want to write a plugin for Quirc, check out [the plugin documentation](https://github.com/nutjob-laboratories/quirc/raw/master/documentation/Quirc-Plugin-Guide.pdf).  For some example plugins, check out [the plugin repository](https://github.com/nutjob-laboratories/quirc-plugins).  Contact [me](mailto:dhetrick@gmail.com) if you've written a plugin and you'd like it included in the repo!
