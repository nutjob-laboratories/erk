#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import os
import argparse

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

app = QApplication(sys.argv)

import qt5reactor
qt5reactor.install()

from twisted.internet import reactor

from quirc.gui.main import QuricGUI
from quirc.common import *

defaults = get_user()

parser = argparse.ArgumentParser(
	prog=f"python {PROGRAM_FILENAME}",
	formatter_class=argparse.RawDescriptionHelpFormatter,
	# description=f"{APPLICATION_NAME} {APPLICATION_VERSION} IRC Client",
	description=ASCII_LOGO,
	epilog=f"""SERVER can be a hostname or IP address, a hostname/port pair (SERVER:PORT), or an IRC URL.

Official Quirc repository: https://github.com/nutjob-laboratories/quirc
Official Quirc plugin repository: https://github.com/nutjob-laboratories/quirc-plugins

Quirc Copyright (C) 2019  Dan Hetrick
""",
	add_help=False,
)

proggroup = parser.add_argument_group('Optional Arguments')

proggroup.add_argument('clserver', metavar='SERVER', type=str, nargs='?', help='Server to connect to on startup', default=None)
proggroup.add_argument('clport', metavar='PORT', type=int, nargs='?', help='Port (6667)', default=0)

# parser.add_argument("-h", "--help", help=f"Displays help", action="help")

devgroup = parser.add_argument_group('Plugin development')

devgroup.add_argument("-e", "--editor", help=f"Opens {EDITOR_NAME}", action="store_true")
devgroup.add_argument("-o","--open", type=str,help=f"Open file in {EDITOR_NAME}",default=None, metavar="FILE")

devgroup.add_argument("-i","--install", type=str,help=f"Install plugin(s) from zip file",default=None, metavar="ZIP_FILE")

netgroup = parser.add_argument_group('Server options')

netgroup.add_argument("-P","--password", type=str,help="Server password",default=None)
netgroup.add_argument("-S", "--ssl", help="Connect via SSL", action="store_true")
netgroup.add_argument("-C","--channel", type=str,help=f"Join CHANNEL on connect",default=None, metavar="CHANNEL[:KEY]")

optgroup = parser.add_argument_group('Options')

optgroup.add_argument("-h", "--help", help=f"Displays help", action="help")

optgroup.add_argument( "--path", type=str, help="Adds a directory to the plugin path", action="append", metavar="DIRECTORY")
optgroup.add_argument( "--maximize", help=f"Display maximized", action="store_true")
optgroup.add_argument( "--fullscreen", help=f"Displays in full screen mode", action="store_true")
optgroup.add_argument( "--ontop", help=f"{APPLICATION_NAME}'s window is always on top", action="store_true")
optgroup.add_argument( "--interval", type=int,help="Keep-alive heartbeat interval (120 seconds)", default=120, metavar="NUMBER")
optgroup.add_argument("-c","--config", type=str,help=f"Use FILE for configuration",default=None, metavar="FILE")
optgroup.add_argument("-d","--display", type=str,help=f"Use FILE for display configuration",default=None, metavar="FILE")

forbidGroup = parser.add_argument_group('Disable features')

forbidGroup.add_argument( "--nologs", help=f"Don't save chat logs on window close", action="store_true")
forbidGroup.add_argument( "--nosettings", help=f"Disable settings menu", action="store_true")
forbidGroup.add_argument( "--noplugins", help=f"Disable plugins", action="store_true")
forbidGroup.add_argument( "--nossl", help=f"Disable SSL", action="store_true")
forbidGroup.add_argument( "--noeditor", help=f"Disable QuircEdit", action="store_true")
forbidGroup.add_argument( "--nowindows", help=f"Disable windows menu", action="store_true")

usergroup = parser.add_argument_group('Set user defaults')

usergroup.add_argument("-n","--nick", type=str,help=f"Set default nickname ({defaults['nick']})", metavar="NICKNAME")
usergroup.add_argument("-a","--alternate", type=str,help=f"Set default alternate nickname ({defaults['alternate']})", metavar="NICKNAME")
usergroup.add_argument("-u","--username", type=str,help=f"Set default username ({defaults['username']})", metavar="USERNAME")
usergroup.add_argument("-r","--realname", type=str,help=f"Set default realname ({defaults['realname']})", metavar="IRCNAME")

args = parser.parse_args()

if args.path:
	for d in args.path:
		if os.path.isdir(d):
			sys.path.append(d)
		else:
			print("Error adding directory to path!")
			print(f"\"{d}\" doesn't exist or is not a directory.")
			sys.exit(1)

if __name__ == '__main__':

	if args.install:
		if installPluginFromZip(args.install):
			print(f"Installed plugins from {args.install}")
			sys.exit(0)
		else:
			print(f"Error installing plugins from {args.install}")
			sys.exit(1)

	app = QApplication([])
	app.setStyle("Windows")

	if args.noplugins:
		if args.config:
			if args.display:
				quircClient = QuricGUI(app,True,args.config,args.display)
			else:
				quircClient = QuricGUI(app,True,args.config)
		else:
			if args.display:
				quircClient = QuricGUI(app,True,None,args.display)
			else:
				quircClient = QuricGUI(app,True)
	else:
		if args.config:
			if args.display:
				quircClient = QuricGUI(app,False,args.config,args.display)
			else:
				quircClient = QuricGUI(app,False,args.config)
		else:
			if args.display:
				quircClient = QuricGUI(app,False,None,args.display)
			else:
				quircClient = QuricGUI(app,False)

	if args.ontop:
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowStaysOnTopHint)

	quircClient.heartbeatInterval = args.interval

	if args.nossl:
		quircClient.can_use_ssl = False

	if args.fullscreen:
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowCloseButtonHint)
		quircClient.setWindowFlags(quircClient.windowFlags() | Qt.WindowType_Mask)
		quircClient.showFullScreen()
	else:
		if args.maximize:
			quircClient.showMaximized()
		else:
			quircClient.show()

	if args.nologs:
		quircClient.turnOffLogging()

	if args.nosettings:
		quircClient.hideSettingsMenu()

	if args.noeditor:
		quircClient.disableEditor()

	if args.nowindows:
		quircClient.disableWindowsMenu()

	user = get_user()
	
	changed = False
	if args.nick:
		user["nick"] = args.nick
		changed = True
	if args.username:
		user["username"] = args.username
		changed = True
	if args.realname:
		user["realname"] = args.realname
		changed = True
	if args.alternate:
		user["alternate"] = args.alternate
		changed = True

	if changed: save_user(user)

	nickname = user["nick"]
	alternate = user["alternate"]
	username = user["username"]
	realname = user["realname"]

	if args.clserver!=None:

		channel = None
		chankey = None

		if "irc://" in args.clserver:
			# got an irc url
			t = args.clserver.replace("irc://","",1)
			tp = t.split('/')
			if len(tp)==2:
				server = tp.pop(0)
				channel = tp.pop(0)
			else:
				server = t
				server = server.replace('/',"")

			args.clserver = server

			# check to see if a channel key is provided
			p = channel.split(":")
			if len(p)==2:
				channel=p[0]
				chankey=p[1]

		p = args.clserver.split(":")
		if len(p)==2:
			server = p[0]
			port = p[1]
		else:
			server = args.clserver
			if args.clport==0:
				port = "6667"
			else:
				port = str(args.clport)

		if args.channel:
			p = args.channel.split(':')
			if len(p)==2:
				channel = p[0]
				key = p[1]
			else:
				channel = args.channel

		if channel!=None:
			quircClient.commandlineJoinChannel = channel

		if chankey!=None:
			quircClient.commandlineJoinChannelKey = chankey

		ci = [nickname,username,realname,alternate,server,port,args.password,args.ssl]
		quircClient.connectToIRC(ci)

	if args.editor:
		quircClient.newEditorWindowMaximized()

	if args.open:
		quircClient.newEditorWindowFileMaximized(args.open)

	reactor.run()
