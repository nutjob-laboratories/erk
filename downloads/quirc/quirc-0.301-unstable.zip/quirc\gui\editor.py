#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import os

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore

from quirc.common import *
from quirc.syntax import QCodeEditor, PythonHighlighter

import quirc.gui.dialogs.newplugin as PluginDialog
import quirc.gui.dialogs.newcommand as CommandDialog

import quirc.gui.find as FindWindow

from quirc.plugins import PluginCollection

class Viewer(QMainWindow):

	def closeEvent(self, event):
		if self.findWindow != None:
			self.findWindow.close()

		if self.parent==None:
			self.close()
			return

		if self.changed:
			self.doExitSave(self.filename)
		
		self.subwindow.close()
		self.close()

	def doNewFile(self):
		if self.changed:
			self.doExitSave(self.filename)

		self.filename = ''
		self.editor.clear()
		self.title = "QuircEdit"
		self.setWindowTitle(self.title)
		self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
		self.changed = False


	def doFileOpen(self):
		options = QFileDialog.Options()
		options |= QFileDialog.DontUseNativeDialog
		fileName, _ = QFileDialog.getOpenFileName(self,"Open Plugin", PLUGIN_DIRECTORY,"Python File (*.py);;All Files (*)", options=options)
		if fileName:
			script = open(fileName,"r")
			self.editor.setPlainText(script.read())
			self.filename = fileName
			self.msav.setEnabled(True)
			self.title = "QuircEdit - " + os.path.basename(fileName)
			self.setWindowTitle(self.title)
			self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
			self.changed = False

	def doFileSave(self):
		code = open(self.filename,"w")
		code.write(self.editor.toPlainText())
		self.setWindowTitle(self.title)
		self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
		self.changed = False

	def doExitSave(self,default):
		options = QFileDialog.Options()
		options |= QFileDialog.DontUseNativeDialog
		fileName, _ = QFileDialog.getSaveFileName(self,"Save Plugin As...",default,"Python File (*.py);;All Files (*)", options=options)
		if fileName:
			if '.py' in fileName:
				pass
			else:
				fileName = fileName + '.py'
			self.filename = fileName
			code = open(fileName,"w")
			code.write(self.editor.toPlainText())

	def doFileSaveAs(self):
		options = QFileDialog.Options()
		options |= QFileDialog.DontUseNativeDialog
		fileName, _ = QFileDialog.getSaveFileName(self,"Save Plugin As...",PLUGIN_DIRECTORY,"Python File (*.py);;All Files (*)", options=options)
		if fileName:
			if '.py' in fileName:
				pass
			else:
				fileName = fileName + '.py'
			self.filename = fileName
			code = open(fileName,"w")
			code.write(self.editor.toPlainText())
			self.msav.setEnabled(True)
			self.title = "QuircEdit - " + os.path.basename(fileName)
			self.setWindowTitle(self.title)
			self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
			self.changed = False

			if self.findWindow!=None:
				f = os.path.basename(self.filename)
				self.findWindow.setWindowTitle(f"Find in {f}")

	def docModified(self):
		if self.count==0:
			self.count = 1
			self.changed = False
			return
		if self.changed: return
		self.setWindowTitle(f"{self.title} *")
		self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
		self.changed = True

	def injectPlugin(self,classname,name,version,description,issilent,isnowindows,isnoirc):
		t = PLUGIN_SKELETON
		t = t.replace(PLUGIN_CLASS,classname)
		t = t.replace(PLUGIN_NAME,name)
		t = t.replace(PLUGIN_VERSION,version)
		t = t.replace(PLUGIN_DESCRIPTION,description)

		if issilent and isnowindows and isnoirc:
			po = "self.silent,self.nowindows,self.noirc = True,True,True"
		elif issilent and isnowindows:
			po = "self.silent,self.nowindows = True,True"
		elif issilent and isnoirc:
			po = "self.silent,self.noirc = True,True"
		elif isnowindows and isnoirc:
			po = "self.nowindows,self.noirc = True,True"
		elif isnoirc:
			po = "self.noirc = True"
		elif issilent:
			po = "self.silent = True"
		elif isnowindows:
			po = "self.nowindows = True"
		else:
			po = ""
		t = t.replace(PLUGIN_OPTIONS,po)

		# self.editor.appendPlainText(t)
		self.editor.insertPlainText(t)

	def doTemplate(self):
		x = PluginDialog.Dialog()
		pinfo = x.get_plugin_information(parent=self)

		if not pinfo: return

		classname = pinfo[0]
		name = pinfo[1]
		version = pinfo[2]
		description = pinfo[3]
		issilent = pinfo[4]
		isnowindows = pinfo[5]
		isnoirc = pinfo[6]

		# Strip spaces from classname
		classname = classname.replace(' ','')

		errs = []
		if len(classname)==0: errs.append("class name not entered")
		if len(name)==0: errs.append("name not entered")
		if len(version)==0: errs.append("version not entered")
		if len(description)==0: errs.append("description not entered")

		if classname.isspace(): errs.append("class name is blank")
		if name.isspace(): errs.append("name is blank")
		if version.isspace(): errs.append("version is blank")
		if description.isspace(): errs.append("description is blank")

		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(EDIT_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Can't inject plugin template")
			msg.exec_()
			return

		i = "from quirc import Plugin"
		if i in self.editor.toPlainText():
			pass
		else:
			self.addToBeginning(i)

		self.injectPlugin(classname,name,version,description,issilent,isnowindows,isnoirc)

	def doCommand(self):
		x = CommandDialog.Dialog()
		pinfo = x.get_plugin_information(parent=self)

		if not pinfo: return

		classname = pinfo[0]
		name = pinfo[1]
		version = pinfo[2]
		description = pinfo[3]
		trigger = pinfo[4]
		issilent = pinfo[5]
		isnowindows = pinfo[6]
		isnoirc = pinfo[7]

		# Strip spaces from classname
		classname = classname.replace(' ','')

		errs = []
		if len(classname)==0: errs.append("class name not entered")
		if len(name)==0: errs.append("name not entered")
		if len(version)==0: errs.append("version not entered")
		if len(description)==0: errs.append("description not entered")
		if len(trigger)==0: errs.append("command name not entered")

		if classname.isspace(): errs.append("class name is blank")
		if name.isspace(): errs.append("name is blank")
		if version.isspace(): errs.append("version is blank")
		if description.isspace(): errs.append("description is blank")
		if trigger.isspace(): errs.append("command name is blank")

		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(EDIT_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Can't inject command template")
			msg.exec_()
			return

		i = "from quirc import Plugin"
		if i in self.editor.toPlainText():
			pass
		else:
			self.addToBeginning(i)

		i = "import shlex"
		if i in self.editor.toPlainText():
			pass
		else:
			self.addToBeginning(i)

		self.injectCommand(classname,name,version,description,trigger,issilent,isnowindows,isnoirc)


	def doPublicCommand(self):
		x = CommandDialog.Dialog()
		pinfo = x.get_plugin_information(parent=self)

		if not pinfo: return

		classname = pinfo[0]
		name = pinfo[1]
		version = pinfo[2]
		description = pinfo[3]
		trigger = pinfo[4]
		issilent = pinfo[5]
		isnowindows = pinfo[6]
		isnoirc = pinfo[7]

		# Strip spaces from classname
		classname = classname.replace(' ','')

		errs = []
		if len(classname)==0: errs.append("class name not entered")
		if len(name)==0: errs.append("name not entered")
		if len(version)==0: errs.append("version not entered")
		if len(description)==0: errs.append("description not entered")
		if len(trigger)==0: errs.append("command name not entered")

		if classname.isspace(): errs.append("class name is blank")
		if name.isspace(): errs.append("name is blank")
		if version.isspace(): errs.append("version is blank")
		if description.isspace(): errs.append("description is blank")
		if trigger.isspace(): errs.append("command name is blank")

		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(EDIT_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Can't inject command template")
			msg.exec_()
			return

		i = "from quirc import Plugin"
		if i in self.editor.toPlainText():
			pass
		else:
			self.addToBeginning(i)

		i = "import shlex"
		if i in self.editor.toPlainText():
			pass
		else:
			self.addToBeginning(i)


		self.injectPublicCommand(classname,name,version,description,trigger,issilent,isnowindows,isnoirc)

	def addToBeginning(self,text):

		code = self.editor.toPlainText()
		self.editor.clear()
		# self.editor.setPlainText(code)
		self.editor.insertPlainText(text)
		self.editor.appendPlainText(code)
		

	def injectPublicCommand(self,classname,name,version,description,trigger,issilent,isnowindows,isnoirc):
		t = PUBLIC_COMMAND_SKELETON
		t = t.replace(PLUGIN_CLASS,classname)
		t = t.replace(PLUGIN_NAME,name)
		t = t.replace(PLUGIN_VERSION,version)
		t = t.replace(PLUGIN_DESCRIPTION,description)
		t = t.replace(PLUGIN_TRIGGER,trigger)

		if issilent and isnowindows and isnoirc:
			po = "self.silent,self.nowindows,self.noirc = True,True,True"
		elif issilent and isnowindows:
			po = "self.silent,self.nowindows = True,True"
		elif issilent and isnoirc:
			po = "self.silent,self.noirc = True,True"
		elif isnowindows and isnoirc:
			po = "self.nowindows,self.noirc = True,True"
		elif isnoirc:
			po = "self.noirc = True"
		elif issilent:
			po = "self.silent = True"
		elif isnowindows:
			po = "self.nowindows = True"
		else:
			po = ""
		t = t.replace(PLUGIN_OPTIONS,po)

		self.editor.insertPlainText(t)
		#self.editor.appendPlainText(t)



	def doPrivateCommand(self):
		x = CommandDialog.Dialog()
		pinfo = x.get_plugin_information(parent=self)

		if not pinfo: return

		classname = pinfo[0]
		name = pinfo[1]
		version = pinfo[2]
		description = pinfo[3]
		trigger = pinfo[4]
		issilent = pinfo[5]
		isnowindows = pinfo[6]
		isnoirc = pinfo[7]

		# Strip spaces from classname
		classname = classname.replace(' ','')

		errs = []
		if len(classname)==0: errs.append("class name not entered")
		if len(name)==0: errs.append("name not entered")
		if len(version)==0: errs.append("version not entered")
		if len(description)==0: errs.append("description not entered")
		if len(trigger)==0: errs.append("command name not entered")

		if classname.isspace(): errs.append("class name is blank")
		if name.isspace(): errs.append("name is blank")
		if version.isspace(): errs.append("version is blank")
		if description.isspace(): errs.append("description is blank")
		if trigger.isspace(): errs.append("command name is blank")

		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(EDIT_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Can't inject command template")
			msg.exec_()
			return

		i = "from quirc import Plugin"
		if i in self.editor.toPlainText():
			pass
		else:
			self.editor.insertPlainText(f"{i}\n")

		i = "import shlex"
		if i in self.editor.toPlainText():
			pass
		else:
			self.editor.insertPlainText(f"{i}\n")

		self.injectPrivateCommand(classname,name,version,description,trigger,issilent,isnowindows,isnoirc)

	def injectPrivateCommand(self,classname,name,version,description,trigger,issilent,isnowindows,isnoirc):
		t = PRIVATE_COMMAND_SKELETON
		t = t.replace(PLUGIN_CLASS,classname)
		t = t.replace(PLUGIN_NAME,name)
		t = t.replace(PLUGIN_VERSION,version)
		t = t.replace(PLUGIN_DESCRIPTION,description)
		t = t.replace(PLUGIN_TRIGGER,trigger)

		if issilent and isnowindows and isnoirc:
			po = "self.silent,self.nowindows,self.noirc = True,True,True"
		elif issilent and isnowindows:
			po = "self.silent,self.nowindows = True,True"
		elif issilent and isnoirc:
			po = "self.silent,self.noirc = True,True"
		elif isnowindows and isnoirc:
			po = "self.nowindows,self.noirc = True,True"
		elif isnoirc:
			po = "self.noirc = True"
		elif issilent:
			po = "self.silent = True"
		elif isnowindows:
			po = "self.nowindows = True"
		else:
			po = ""
		t = t.replace(PLUGIN_OPTIONS,po)

		# self.editor.appendPlainText(t)
		self.editor.insertPlainText(t)





	def injectCommand(self,classname,name,version,description,trigger,issilent,isnowindows,isnoirc):
		t = COMMAND_SKELETON
		t = t.replace(PLUGIN_CLASS,classname)
		t = t.replace(PLUGIN_NAME,name)
		t = t.replace(PLUGIN_VERSION,version)
		t = t.replace(PLUGIN_DESCRIPTION,description)
		t = t.replace(PLUGIN_TRIGGER,trigger)

		if issilent and isnowindows and isnoirc:
			po = "self.silent,self.nowindows,self.noirc = True,True,True"
		elif issilent and isnowindows:
			po = "self.silent,self.nowindows = True,True"
		elif issilent and isnoirc:
			po = "self.silent,self.noirc = True,True"
		elif isnowindows and isnoirc:
			po = "self.nowindows,self.noirc = True,True"
		elif isnoirc:
			po = "self.noirc = True"
		elif issilent:
			po = "self.silent = True"
		elif isnowindows:
			po = "self.nowindows = True"
		else:
			po = ""
		t = t.replace(PLUGIN_OPTIONS,po)

		#self.editor.appendPlainText(t)
		self.editor.insertPlainText(t)

	def hasUndo(self,avail):
		if avail:
			self.meun.setEnabled(True)
		else:
			self.meun.setEnabled(False)

	def hasRedo(self,avail):
		if avail:
			self.mere.setEnabled(True)
		else:
			self.mere.setEnabled(False)

	def hasCopy(self,avail):
		if avail:
			self.mecopy.setEnabled(True)
			self.mecut.setEnabled(True)
		else:
			self.mecopy.setEnabled(False)
			self.mecut.setEnabled(False)

	def doFind(self):

		if self.findWindow != None:
			self.findWindow.showNormal()
			return

		if self.parent==None:
			self.findWindow = FindWindow.Viewer(self,True)
			self.findWindow.show()
			return

		x = self.parent.newFindWindow(self)

	def setFindWindow(self,obj):
		self.findWindow = obj

	def toggleFindtop(self):
		if self.findOnTop:
			self.findOnTop = False
			if self.findWindow != None:
				self.findWindow.setWindowFlags(self.findWindow.windowFlags() & ~Qt.WindowStaysOnTopHint)
		else:
			self.findOnTop = True
			if self.findWindow != None:
				self.findWindow.setWindowFlags(self.findWindow.windowFlags() | Qt.WindowStaysOnTopHint)
		self.settings[EDITOR_FIND_ON_TOP] = self.findOnTop
		save_editor_settings(self.settings)

	def toggleWrap(self):
		if self.wordwrap:
			self.wordwrap = False
			self.editor.setWordWrapMode(QTextOption.NoWrap)
			self.editor.update()
			self.update()
		else:
			self.wordwrap = True
			self.editor.setWordWrapMode(QTextOption.WordWrap)
			self.editor.update()
			self.update()

		self.settings[EDITOR_WORD_WRAP_SETTING] = self.wordwrap
		save_editor_settings(self.settings)

	def getFont(self):
		font, ok = QFontDialog.getFont()
		if ok:

			self.editor.setFont(font)

			self.settings[EDITOR_FONT_SETTING] = font.toString()
			save_editor_settings(self.settings)

	def __init__(self,filename=None,parent=None):
		super(Viewer, self).__init__(parent)

		self.parent = parent
		self.filename = ''
		self.title = "QuircEdit"
		self.count = 0
		self.subwindow = None

		self.findWindow = None

		self.wordwrap = True

		self.findOnTop = True

		self.settings = get_editor_settings()
		self.wordwrap = self.settings[EDITOR_WORD_WRAP_SETTING]
		self.font = self.settings[EDITOR_FONT_SETTING]
		self.findOnTop = self.settings[EDITOR_FIND_ON_TOP]

		self.setWindowTitle(self.title)
		self.setWindowIcon(QIcon(EDIT_ICON))

		self.editor = QCodeEditor(self)
		self.highlight = PythonHighlighter(self.editor.document())

		self.editor.textChanged.connect(self.docModified)
		self.editor.redoAvailable.connect(self.hasRedo)
		self.editor.undoAvailable.connect(self.hasUndo)
		self.editor.copyAvailable.connect(self.hasCopy)

		f = QFont()
		f.fromString(self.font)
		self.editor.setFont(f)

		self.setCentralWidget(self.editor)

		if self.wordwrap:
			self.editor.setWordWrapMode(QTextOption.WordWrap)
		else:
			self.editor.setWordWrapMode(QTextOption.NoWrap)

		self.indentspace = self.settings[EDITOR_SPACES_TAB_SETTING]
		self.tabsize = self.settings[EDITOR_NUMBER_OF_SPACES]

		self.menubar = self.menuBar()
		self.changed = False

		fileMenu = self.menubar.addMenu("File")

		mnf = QAction(QIcon(NEWFILE_ICON),"New file",self)
		mnf.triggered.connect(self.doNewFile)
		mnf.setShortcut("Ctrl+N")
		fileMenu.addAction(mnf)

		mop = QAction(QIcon(OPEN_ICON),"Open file",self)
		mop.triggered.connect(self.doFileOpen)
		mop.setShortcut("Ctrl+O")
		fileMenu.addAction(mop)

		fileMenu.addSeparator()

		self.msav = QAction(QIcon(SAVE_ICON),"Save file",self)
		self.msav.triggered.connect(self.doFileSave)
		self.msav.setShortcut("Ctrl+S")
		fileMenu.addAction(self.msav)
		self.msav.setEnabled(False)

		msava = QAction(QIcon(SAVEAS_ICON),"Save as...",self)
		msava.triggered.connect(self.doFileSaveAs)
		fileMenu.addAction(msava)

		fileMenu.addSeparator()

		mex = QAction(QIcon(EXIT_ICON),"Exit",self)
		mex.triggered.connect(self.close)
		fileMenu.addAction(mex)

		editMenu = self.menubar.addMenu("Edit")

		mefind = QAction(QIcon(WHOIS_ICON),"Find",self)
		mefind.triggered.connect(self.doFind)
		mefind.setShortcut("Ctrl+F")
		editMenu.addAction(mefind)

		editMenu.addSeparator()

		mesela = QAction(QIcon(SELECTALL_ICON),"Select All",self)
		mesela.triggered.connect(self.editor.selectAll)
		mesela.setShortcut("Ctrl+A")
		editMenu.addAction(mesela)

		editMenu.addSeparator()

		self.meun = QAction(QIcon(UNDO_ICON),"Undo",self)
		self.meun.triggered.connect(self.editor.undo)
		self.meun.setShortcut("Ctrl+Z")
		editMenu.addAction(self.meun)
		self.meun.setEnabled(False)

		self.mere = QAction(QIcon(REDO_ICON),"Redo",self)
		self.mere.triggered.connect(self.editor.redo)
		self.mere.setShortcut("Ctrl+Y")
		editMenu.addAction(self.mere)
		self.mere.setEnabled(False)

		editMenu.addSeparator()

		self.mecut = QAction(QIcon(CUT_ICON),"Cut",self)
		self.mecut.triggered.connect(self.editor.cut)
		self.mecut.setShortcut("Ctrl+X")
		editMenu.addAction(self.mecut)
		self.mecut.setEnabled(False)

		self.mecopy = QAction(QIcon(COPY_ICON),"Copy",self)
		self.mecopy.triggered.connect(self.editor.copy)
		self.mecopy.setShortcut("Ctrl+C")
		editMenu.addAction(self.mecopy)
		self.mecopy.setEnabled(False)

		mepaste = QAction(QIcon(CLIPBOARD_ICON),"Paste",self)
		mepaste.triggered.connect(self.editor.paste)
		mepaste.setShortcut("Ctrl+V")
		editMenu.addAction(mepaste)

		editMenu.addSeparator()

		mezoomin = QAction(QIcon(PLUS_ICON),"Zoom in",self)
		mezoomin.triggered.connect(self.editor.zoomIn)
		mezoomin.setShortcut("Ctrl++")
		editMenu.addAction(mezoomin)

		mezoomout = QAction(QIcon(MINUS_ICON),"Zoom out",self)
		mezoomout.triggered.connect(self.editor.zoomOut)
		mezoomout.setShortcut("Ctrl+-")
		editMenu.addAction(mezoomout)

		pluginsMenu = self.menubar.addMenu("Templates")

		mist = QAction(QIcon(PLUGIN_ICON),"Insert plugin template",self)
		mist.triggered.connect(self.doTemplate)
		pluginsMenu.addAction(mist)


		miscc = QAction(QIcon(COMMAND_ICON),"Insert Quirc command template",self)
		miscc.triggered.connect(self.doCommand)
		pluginsMenu.addAction(miscc)

		mispub = QAction(QIcon(PUBLIC_ICON),"Insert public command template",self)
		mispub.triggered.connect(self.doPublicCommand)
		pluginsMenu.addAction(mispub)

		mispriv = QAction(QIcon(PRIVATE_ICON),"Insert private command template",self)
		mispriv.triggered.connect(self.doPrivateCommand)
		pluginsMenu.addAction(mispriv)

		settingsMenu = self.menubar.addMenu("Settings")

		optFont = QAction(QIcon(FONT_ICON),"Set font",self)
		optFont.triggered.connect(self.getFont)
		settingsMenu.addAction(optFont)

		self.optWrap = QAction(QIcon(WRAP_ICON),"Word wrap",self,checkable=True)
		self.optWrap.setChecked(self.wordwrap)
		self.optWrap.triggered.connect(self.toggleWrap)
		settingsMenu.addAction(self.optWrap)

		numIndentMenu = settingsMenu.addMenu(QIcon(INDENT_ICON),"Indentation")

		self.tabs = QAction("Use tabs",self,checkable=True)
		self.tabs.triggered.connect(lambda state,f=0: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.tabs)

		numIndentMenu.addSeparator()

		self.opt1 = QAction("Use 1 space",self,checkable=True)
		self.opt1.triggered.connect(lambda state,f=1: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.opt1)

		self.opt2 = QAction("Use 2 spaces",self,checkable=True)
		self.opt2.triggered.connect(lambda state,f=2: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.opt2)

		self.opt3 = QAction("Use 3 spaces",self,checkable=True)
		self.opt3.triggered.connect(lambda state,f=3: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.opt3)

		self.opt4 = QAction("Use 4 spaces",self,checkable=True)
		self.opt4.triggered.connect(lambda state,f=4: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.opt4)

		self.opt5 = QAction("Use 5 spaces",self,checkable=True)
		self.opt5.triggered.connect(lambda state,f=5: self.setSpaceIndent(f))
		numIndentMenu.addAction(self.opt5)

		if self.indentspace:
			if self.tabsize==1:
				self.opt1.setChecked(True)
			elif self.tabsize==2:
				self.opt2.setChecked(True)
			elif self.tabsize==3:
				self.opt3.setChecked(True)
			elif self.tabsize==4:
				self.opt4.setChecked(True)
			elif self.tabsize==5:
				self.opt5.setChecked(True)
		else:
			self.tabs.setChecked(True)

		settingsMenu.addSeparator()

		self.optFind = QAction("Find window always on top",self,checkable=True)
		self.optFind.setChecked(self.findOnTop)
		self.optFind.triggered.connect(self.toggleFindtop)
		settingsMenu.addAction(self.optFind)

		#settingsMenu.addSeparator()

		# preload = QAction(QIcon(LOAD_ICON),"Load new packages",self)
		# preload.triggered.connect(lambda state: self.parent.reloadPlugins())
		# settingsMenu.addAction(preload)

		# prestart = QAction(QIcon(RESTART_ICON),"Restart Quirc",self)
		# prestart.triggered.connect(lambda state: restart_program())
		# settingsMenu.addAction(prestart)

		if filename!=None:
			self.filename = filename
			script = open(filename,"r")
			self.editor.setPlainText(script.read())
			self.title = "QPyEdit - " + os.path.basename(filename)
			self.setWindowTitle(self.title)
			self.parent.updateActiveChild(self.parent.MDI.activeSubWindow())
			self.msav.setEnabled(True)

	def setSpaceIndent(self,num):
		if num>0:
			self.indentspace = True
			self.tabsize = num
			self.tabs.setChecked(False)
		else:
			self.indentspace = False
			self.tabs.setChecked(True)

		self.settings[EDITOR_SPACES_TAB_SETTING] = self.indentspace
		self.settings[EDITOR_NUMBER_OF_SPACES] = self.tabsize
		save_editor_settings(self.settings)

		self.opt2.setChecked(False)
		self.opt3.setChecked(False)
		self.opt4.setChecked(False)
		self.opt5.setChecked(False)

		if num==2:
			self.opt2.setChecked(True)
		elif num==3:
			self.opt3.setChecked(True)
		elif num==4:
			self.opt4.setChecked(True)
		elif num==5:
			self.opt5.setChecked(True)
