#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import os
import json
import re
from datetime import datetime

# Globally load in Quirc's resource file
globals()["quirc.resources"] = __import__("quirc.resources")

import quirc.colour

# Plugin event names

EVENT_LOAD				= "event_load"
EVENT_UNLOAD			= "event_unload"
EVENT_CONNECTED			= "event_connected"
EVENT_DISCONNECTED		= "event_disconnected"
EVENT_REGISTERED		= "event_registered"
EVENT_PUBLIC			= "event_public"
EVENT_PRIVATE			= "event_private"
EVENT_NOTICE			= "event_notice"
EVENT_ACTION			= "event_action"
EVENT_JOIN				= "event_join"
EVENT_PART				= "event_part"
EVENT_MODE				= "event_mode"
EVENT_QUIT				= "event_quit"
EVENT_TOPIC				= "event_topic"
EVENT_INVITE			= "event_invite"
EVENT_MOTD				= "event_motd"
EVENT_MENU				= "event_menu"
EVENT_TICK				= "event_tick"
EVENT_INPUT				= "event_input"

# Directories
INSTALL_DIRECTORY = sys.path[0]
QUIRC_DIRECTORY = os.path.join(INSTALL_DIRECTORY, "quirc")
LOG_DIRECTORY = os.path.join(INSTALL_DIRECTORY, "logs")
SETTINGS_DIRECTORY = os.path.join(INSTALL_DIRECTORY, "settings")
PLUGIN_DIRECTORY = os.path.join(INSTALL_DIRECTORY, "plugins")

# Files
DISPLAY_CONFIGURATION = os.path.join(SETTINGS_DIRECTORY, "display.json")
IRC_NETWORK_LIST = os.path.join(QUIRC_DIRECTORY, "servers.txt")
LAST_SERVER_INFORMATION_FILE = os.path.join(SETTINGS_DIRECTORY, "lastserver.json")
USER_FILE = os.path.join(SETTINGS_DIRECTORY, "user.json")
SETTINGS_FILE = os.path.join(SETTINGS_DIRECTORY, "settings.json")
EDITOR_SETTINGS_FILE = os.path.join(SETTINGS_DIRECTORY, "editor.json")

# Globals
APPLICATION_NAME = "Quirc"
APPLICATION_VERSION = "0.300"

DEFAULT_NICKNAME = "quirc"
DEFAULT_USERNAME = "quirc"
DEFAULT_IRCNAME = f"{APPLICATION_NAME} {APPLICATION_VERSION}"

TOOLBAR_BUTTON_HEIGHT = 25

NEW_CHAT_DIVIDER = """<table style="width: 100%; height: 5px;" border="0"><tbody><tr><td style="background-color: #cccccc; font-size:small;"><i>&nbsp;New chat&nbsp;</i></td></tr></tbody></table>"""

TIMESTAMP_TEMPLATE = """<td style="vertical-align:top; font-size:small; text-align:center;"><i>!TIME!</i></td><td style="font-size:small;">&nbsp;</td>"""

PLAIN_MESSAGE_TEMPLATE = """
<table style="width: 100%;" border="0">
  <tbody>
	<tr>!TIMESTAMP!
	  <td style="text-align: left; vertical-align: top; background: \"!BACKGROUND!\";"><font color="!COLOR!"><b>!MESSAGE!</b></font></td>
	</tr>
  </tbody>
</table>
"""

CHAT_MESSAGE_TEMPLATE = f"""
<table style="width: 100%;" border="0">
  <tbody>
	<tr>!TIMESTAMP!
	  <td style="text-align: right; vertical-align: top; !GRADIENT!"><font color="!COLOR!">!USER!</font></td>
	  <td style="text-align: left; vertical-align: top; background: \"!BACKGROUND!\";">&nbsp;</td>
	  <td style="text-align: left; vertical-align: top; background: \"!BACKGROUND!\";"><font color="!CCHAT!">!MESSAGE!</font></td>
	</tr>
  </tbody>
</table>
"""

LOG_MESSAGE_TEMPLATE = f"""
<table style="width: 100%;" border="0">
  <tbody>
	<tr>!TIMESTAMP!
	  <td style="text-align: right; vertical-align: top;"><font color="!COLOR!">!USER!</font></td>
	  <td style="text-align: left; vertical-align: top; background: \"!BACKGROUND!\";">&nbsp;</td>
	  <td style="text-align: left; vertical-align: top; background: \"!BACKGROUND!\";"><font color="!CCHAT!">!MESSAGE!</font></td>
	</tr>
  </tbody>
</table>
"""

ACTION_MESSAGE_TEMPLATE = """
<table style="width: 100%;" border="0">
  <tbody>
	<tr>!TIMESTAMP!
	  <td style="text-align: left; vertical-align: top; !GRADIENT!"><font color="!COLOR!"><b>!USER!</b> !MESSAGE!</font></td>
	</tr>
  </tbody>
</table>
"""

LOG_TIMESTAMP = 0
LOG_TEXT = 1

AUTOJOIN_DELIMITER = "/"

GRADIENT_LIGHTEN = 0.95

MAX_USERNAME_SIZE = 16

INITIAL_WINDOW_WIDTH = 500
INITIAL_WINDOW_HEIGHT = 350

ADDITIONAL_POINT_SIZE_FOR_USER_DISPLAY = 1

# Graphics

MDI_BACKGROUND = ":/background.png"
QUIRC_LOG_LOGO = ":/logbg.png"
QUIRC_SMALL_LOGO = ":/logo_226x100.png"

# Icons

QUIRC_ICON = ":/quirc.png"
SERVER_ICON = ":/server.png"
NETWORK_ICON = ":/network.png"
USER_WINDOW_ICON = ":/userwindow.png"
CHANNEL_WINDOW_ICON = ":/channelwindow.png"
LOCKED_ICON = ":/locked.png"
CASCADE_ICON = ":/cascade.png"
TILE_ICON = ":/tile.png"
EXIT_ICON = ":/exit.png"
DISCONNECT_ICON = ":/disconnect.png"
USER_ICON = ":/user.png"
TOOLBAR_DISCONNECT_ICON = ":/toolbardisconnect.png"
BAN_ICON = ":/ban.png"
MODERATED_ICON = ":/moderated.png"
UNKNOWN_ICON = ":/unknown.png"
SAVE_ICON = ":/save.png"
CLIPBOARD_ICON = ":/clipboard.png"
FONT_ICON = ":/font.png"
PLUS_ICON = ":/plus.png"
MINUS_ICON = ":/minus.png"
NEW_WINDOW_ICON = ":/newwindow.png"
WHOIS_ICON = ":/whois.png"
LOG_ICON = ":/log.png"
KICK_ICON = ":/kick.png"
MODULE_ICON = ":/module.png"
PLUGIN_ICON = ":/plugin.png"
EDIT_ICON = ":/edit.png"
SAVEAS_ICON = ":/saveas.png"
OPEN_ICON = ":/open.png"
SELECTALL_ICON = ":/selectall.png"
CUT_ICON = ":/cut.png"
COPY_ICON = ":/copy.png"
UNDO_ICON = ":/undo.png"
REDO_ICON = ":/redo.png"
INDENT_ICON = ":/indent.png"
WRAP_ICON = ":/wrap.png"
NOWRAP_ICON = ":/nowrap.png"
COMMAND_ICON = ":/command.png"
RESTART_ICON = ":/restart.png"
NEWFILE_ICON = ":/newfile.png"
RELOAD_ICON = ":/reload.png"

#Objects

class QuircWindow(object):

	def __init__(self,name,server,window,subwindow):
		self.name = name
		self.server = server
		self.window = window
		self.subwindow = subwindow

class ircConnection(object):

	def __init__(self):
		self.irc = None		# IRC connection object
		self.server = None
		self.port = 0

class Whowas(object):

	def __init__(self):

		self.name = ''
		self.username = ''
		self.host = ''
		self.realname = ''

class Whois(object):

	def __init__(self):

		self.name = ''
		self.channels = []
		self.username = ''
		self.host = ''
		self.realname = ''
		self.idle = 0
		self.signedon = ''
		self.server = ''

# Functions

def restart_program():
	python = sys.executable
	os.execl(python, python, * sys.argv)

def restart_program_no_arg():
	python = sys.executable
	sys.argv.pop()
	os.execl(python, python, * sys.argv)

def get_editor_settings():
	if os.path.isfile(EDITOR_SETTINGS_FILE):
		with open(EDITOR_SETTINGS_FILE, "r") as read_settings:
			data = json.load(read_settings)
			return data
	else:
		si = {
			"font": "Consolas,10,-1,5,50,0,0,0,0,0,Regular",
			"wrap": False,
			"spaces": True,
			"indent": 2,

		}
		return si

def save_editor_settings(data):
	with open(EDITOR_SETTINGS_FILE, "w") as write_data:
		json.dump(data, write_data, indent=4, sort_keys=True)

def timestamp_to_date(ts):
	dt_object = datetime.fromtimestamp(int(ts))
	return dt_object.strftime("%m/%d/%Y, %H:%M:%S")

def makeWhoisPretty(w):
	sot = timestamp_to_date(w.signedon)
	t = f"""<b>Nickname:</b> {w.name}<br>
<b>Username:</b> {w.username}<br>
<b>Real Name:</b> {w.realname}<br>
<b>Host:</b> {w.host}<br>
<b>Connected to:</b> {w.server}<br>
<b>Signed on:</b> {sot}<br>
<b>Idle:</b> {w.idle} seconds<br>
<b>Channels:</b> {', '.join(w.channels)}"""
	return t

def cmdHelp():
	h = [
		f"<u>{APPLICATION_NAME} {APPLICATION_VERSION} Command Help</u>",
		"/help - <i>Displays command help</i>",
		"/msg TARGET MESSAGE - <i>Sends MESSAGE to TARGET</i>",
		"/notice TARGET MESSAGE - <i>Sends a notice to TARGET</i>",
		"/me MESSAGE - <i>Sends a CTCP action message</i>",
		"/join CHANNEL [KEY] - <i>Joins a channel</i>",
		"/part [CHANNEL] - <i>Leaves a channel</i>",
		"/away [MESSAGE] - <i>Sets you as \"away\"</i>",
		"/back - <i>Sets you as \"back\"</i>",
		"/invite USER [CHANNEL] - <i>Sends a channel invitation</i>",
		"/kick [CHANNEL] USER [REASON] - <i>Kicks a user from a channel</i>",
	]
	return h

def convertSeconds(seconds):
	h = seconds//(60*60)
	m = (seconds-h*60*60)//60
	s = seconds-(h*60*60)-(m*60)
	return [h, m, s]

def is_integer(n):
	try:
		int(n)
	except ValueError:
		return False
	return True

def save_autojoin_channels(server,chans):
	AUTOJOIN_FILE = os.path.join(SETTINGS_DIRECTORY, f"{server}-autojoin.json")
	with open(AUTOJOIN_FILE, "w") as write_data:
		json.dump(chans, write_data, indent=4, sort_keys=True)

def get_autojoins(server):
	AUTOJOIN_FILE = os.path.join(SETTINGS_DIRECTORY, f"{server}-autojoin.json")
	if os.path.isfile(AUTOJOIN_FILE):
		with open(AUTOJOIN_FILE, "r") as read_server:
			data = json.load(read_server)
			return data
	else:
		return []

def save_last_server(host,port,password,ssl):
	sinfo = {
			"host": host,
			"port": port,
			"password": password,
			"ssl": ssl
		}
	with open(LAST_SERVER_INFORMATION_FILE, "w") as write_data:
		json.dump(sinfo, write_data, indent=4, sort_keys=True)

def get_last_server():
	if os.path.isfile(LAST_SERVER_INFORMATION_FILE):
		with open(LAST_SERVER_INFORMATION_FILE, "r") as read_server:
			data = json.load(read_server)
			return data
	else:
		si = {
			"host": '',
			"port": '',
			"password": '',
			"ssl": False
		}
		return si

def get_user():
	if os.path.isfile(USER_FILE):
		with open(USER_FILE, "r") as read_user:
			data = json.load(read_user)
			return data
	else:
		si = {
			"nick": DEFAULT_NICKNAME,
			"username": DEFAULT_USERNAME,
			"realname": DEFAULT_IRCNAME
		}
		return si

def save_user(user):
	with open(USER_FILE, "w") as write_data:
		json.dump(user, write_data, indent=4, sort_keys=True)

# SETTINGS_FILE

def saveSettings(settings):
	with open(SETTINGS_FILE, "w") as write_data:
		json.dump(settings, write_data, indent=4, sort_keys=True)

def loadSettings():
	if os.path.isfile(SETTINGS_FILE):
		with open(SETTINGS_FILE, "r") as read_settings:
			data = json.load(read_settings)
			return data
	else:
		s = {
			"timestamp": True,
			"uptime": True,
			"reconnect": True,
			"keepalive": True,
			"invite": False,
			"private": True,
			"iwidth": INITIAL_WINDOW_WIDTH,
			"iheight": INITIAL_WINDOW_HEIGHT
		}
		return s


def saveDisplay(settings):
	with open(DISPLAY_CONFIGURATION, "w") as write_data:
		json.dump(settings, write_data, indent=4, sort_keys=True)

def loadDisplay():
	if os.path.isfile(DISPLAY_CONFIGURATION):
		with open(DISPLAY_CONFIGURATION, "r") as read_settings:
			data = json.load(read_settings)
			return data
	else:
		s = {
			"font": "Consolas,10,-1,5,50,0,0,0,0,0,Regular",
			"text": "#000000",
			"background": "#ffffff",
			"system": "#FF9C00",
			"self": "#FF0000",
			"user": "#00007F",
			"action": "#009300",
			"notice": "#9C009C"
		}
		return s

def saveLog(serverid,name,logs):
	serverid = serverid.replace(":","-")
	f = f"{serverid}_{name}.json"
	logfile = os.path.join(LOG_DIRECTORY,f)

	with open(logfile, "w") as writelog:
		json.dump(logs, writelog, indent=4, sort_keys=True)

def loadLog(serverid,name):
	serverid = serverid.replace(":","-")
	f = f"{serverid}_{name}.json"
	logfile = os.path.join(LOG_DIRECTORY,f)

	if os.path.isfile(logfile):
		with open(logfile, "r") as logentries:
			data = json.load(logentries)
			return data
	else:
		return []

def encodeWindowLink(serverid,user):
	l = f"{serverid}___{user}"
	l = l.replace(":","&")
	return f"{l}"

def decodeWindowLink(link):
	l = link.replace("&",":")
	return l.split("___")

def systemTextDisplay(text,foreground,background):
	msg = PLAIN_MESSAGE_TEMPLATE.replace('!COLOR!',foreground)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!MESSAGE!',text)

	return msg

def pad_nick(nick,size):
	x = size - len(nick)
	if x<0 : x = 0
	y = '&nbsp;'*x
	return f"{y}{nick}"

def remove_html_markup(s):
	tag = False
	quote = False
	out = ""

	for c in s:
			if c == '<' and not quote:
				tag = True
			elif c == '>' and not quote:
				tag = False
			elif (c == '"' or c == "'") and tag:
				quote = not quote
			elif not tag:
				out = out + c

	return out

def inject_www_links(txt):
	urls = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', txt)
	for u in urls:
		u = re.sub('<[^<]+?>', '', u)
		link = f"<a href=\"{u}\"><span style=\"text-decoration: underline; font-weight: bold; color: blue\">{u}</span></a>"
		txt = txt.replace(u,link)
	return txt

def chat_display(user,text,max,dolink,namecolor,foreground,background):
	text = remove_html_markup(text)
	user = pad_nick(user,max)
	if dolink: text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def whois_display(text,max,namecolor,foreground,background):
	user = pad_nick("WHOIS",max)
	#text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def motd_display(text,max,dolink,namecolor,foreground,background):
	user = pad_nick("MOTD",max)
	if dolink: text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def log_chat_display(user,text,max,dolink,namecolor,foreground,background):
	text = remove_html_markup(text)
	#user = pad_nick(user,max)
	if dolink: text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# # Gradient
	# BG = quirc.colour.Color(background)
	# LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	# USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	# msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def mychat_display(user,text,max,dolink,namecolor,foreground,background):
	text = remove_html_markup(text)
	user = pad_nick(user,max)
	if dolink: text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def action_display(user,text,dolink,namecolor,background):
	text = remove_html_markup(text)
	if dolink: text = inject_www_links(text)
	msg = ACTION_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def notice_display(user,text,max,dolink,namecolor,foreground,background):
	text = remove_html_markup(text)
	user = pad_nick(user,max)
	if dolink: text = inject_www_links(text)
	msg = CHAT_MESSAGE_TEMPLATE.replace('!USER!',user)
	msg = msg.replace('!COLOR!',namecolor)
	msg = msg.replace('!BACKGROUND!',background)
	msg = msg.replace('!CCHAT!',foreground)
	msg = msg.replace('!MESSAGE!',text)

	# Gradient
	BG = quirc.colour.Color(background)
	LIGHT_COLOR = quirc.colour.Color(namecolor,luminance=GRADIENT_LIGHTEN)
	USER_BACKGROUND_GRADIENT = f"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 {BG}, stop:1 {LIGHT_COLOR});"
	msg = msg.replace("!GRADIENT!",USER_BACKGROUND_GRADIENT)

	return msg

def convertLogToPlaintext(log):
	d = []
	for l in log:
		time = l[LOG_TIMESTAMP]
		text = l[LOG_TEXT]

		text = text.replace("!TIMESTAMP!","")
		text = remove_html_markup(text)
		text = text.replace("\n","")
		text = text.replace("&nbsp;","")
		text = text.strip()
		text = re.sub("[\t ]{2,}", "\t", text)
		text = text.replace("\t",":")
		d.append(f"{time} {text}")
	return "\n".join(d)

def convertLogToHtml(log):
	d = []
	for l in log:
		time = l[LOG_TIMESTAMP]
		text = l[LOG_TEXT]

		text = text.replace("!TIMESTAMP!","")
		d.append(f"{time} {text}")
	return "\n".join(d)

PLUGIN_CLASS = '%CLASS%'
PLUGIN_NAME = '%NAME%'
PLUGIN_VERSION = '%VERSION%'
PLUGIN_DESCRIPTION = '%DESCRIPTION%'
PLUGIN_TRIGGER = '%COMMAND%'

COMMAND_SKELETON = f"""
class %CLASS%(Plugin):

  def __init__(self):
    self.name = "%NAME%"
    self.version = "%VERSION%"
    self.description = "%DESCRIPTION%"

    self.command = "%COMMAND%"

  # Executed when the text is inputted into the client
  # Arguments:    server (str) - The ID of the server
  #               source (str) - The window the client input text into
  #               text (str) - The input text
  def {EVENT_INPUT}(self,server,source,text):
    tokens = shlex.split(text)
    if len(tokens)>0 and tokens[0].lower()==self.command:
      tokens.pop(0)

      # server = the ID of the server
      # source = the name of the window the command was input into
      # token = a list of arguments passed to the command

      # Command functionality goes here

      # Return a true value so the inputted text isn't
      # sent to the IRC server as chat
      return True
"""

PLUGIN_SKELETON = f"""
class %CLASS%(Plugin):

  def __init__(self):
    self.name = "%NAME%"
    self.version = "%VERSION%"
    self.description = "%DESCRIPTION%"

    # Set self.silent to "True" to prevent chat messages
    # from being displayed in the client's windows
    self.silent = False

  # =================
  # | CLIENT EVENTS |
  # =================

  # Executed as soon as the plugin is loaded
  def {EVENT_LOAD}(self):
    pass

  # Executed when the client exits
  def {EVENT_UNLOAD}(self):
    pass

  # Executed when the plugin's name is clicked in
  # the "Plugins" menu
  def {EVENT_MENU}(self):
    pass

  # Executes roughly once per second
  # {EVENT_TICK} is executed once for each connected server
  # Arguments:    server (str) - The ID of the server
  #               uptime (int) - The uptime of the client, in seconds 
  def {EVENT_TICK}(self,server,uptime):
    pass

  # Executed when the text is inputted into the client
  # Arguments:    server (str) - The ID of the server
  #               source (str) - The window the client input text into
  #               text (str) - The input text
  def {EVENT_INPUT}(self,server,source,text):
    pass

  # ==============
  # | IRC EVENTS |
  # ==============

  # Executed when the client connects to an IRC server
  # Arguments:    server (str) - The ID of the server connected to
  def {EVENT_CONNECTED}(self,server):
    pass

  # Executed when the client disconnected from an IRC server
  # Arguments:    server (str) - The ID of the server disconnected from
  #               reason (str) - The reason for the disconnection
  def {EVENT_DISCONNECTED}(self,server,reason):
    pass

  # Executed when the client registers with an IRC server
  # Arguments:    server (str) - The ID of the server registered with
  def {EVENT_REGISTERED}(self,server):
    pass

  # Executed when the client receives the MOTD from a server
  # Arguments:    server (str) - The ID of the server the part occurred on
  #               motd (list) - A list of strings containing the MOTD
  def {EVENT_MOTD}(self,server,motd):
    pass

  # Executed when the client receives a public message
  # Arguments:    server (str) - The ID of the server that sent the message
  #               channel (str) - The channel the message was sent to
  #               user (str) - The sender of the message
  #               message (str) - The message
  def {EVENT_PUBLIC}(self,server,channel,user,message):
    pass

  # Executed when the client receives a private message
  # Arguments:    server (str) - The ID of the server that sent the message
  #               user (str) - The sender of the message
  #               message (str) - The message
  def {EVENT_PRIVATE}(self,server,user,message):
    pass

  # Executed when the client receives a notice
  # Arguments:    server (str) - The ID of the server that sent the message
  #               channel (str) - The channel the message was sent to
  #               user (str) - The sender of the message
  #               message (str) - The message
  def {EVENT_NOTICE}(self,server,channel,user,message):
    pass

  # Executed when the client receives CTCP action message
  # Arguments:    server (str) - The ID of the server that sent the message
  #               channel (str) - The channel the message was sent to
  #               user (str) - The sender of the message
  #               message (str) - The message
  def {EVENT_ACTION}(self,server,channel,user,message):
    pass

  # Executed when a user joins a channel the client is in
  # Arguments:    server (str) - The ID of the server the join occurred on
  #               channel (str) - The channel joined
  #               user (str) - The user joining
  def {EVENT_JOIN}(self,server,channel,user):
    pass

  # Executed when a user leaves a channel the client is in
  # Arguments:    server (str) - The ID of the server the part occurred on
  #               channel (str) - The channel left
  #               user (str) - The user leaving
  def {EVENT_PART}(self,server,channel,user):
    pass

  # Executed when the client receives a channel invite
  # Arguments:    server (str) - The ID of the server the invite occurred on
  #               channel (str) - The channel invited to
  #               user (str) - The user who sent the invite
  def {EVENT_INVITE}(self,server,channel,user):
    pass

  # Executed when the topic is changed in a channel the client is in
  # Arguments:    server (str) - The ID of the server
  #               channel (str) - The channel that had its topic changed
  #               user (str) - The user who changed the topic
  #               topic (str) - The new topic
  def {EVENT_TOPIC}(self,server,channel,user,topic):
    pass

  # Executed when a user disconnects from the IRC server
  # Arguments:    server (str) - The ID of the server
  #               user (str) - The user disconnecting
  #               message (str) - An optional parting message
  def {EVENT_QUIT}(self,server,user,message):
    pass

  # Executed when the client receives a mode message
  # Arguments:    server (str) - The ID of the server
  #               mset (bool) - True for setting a mode, False for unsetting
  #               user (str) - The user who set the mode
  #               target (str) - The channel or user the mode was set or unset on
  #               modes (str) - The modes set
  #               args (list) - Any mode arguments
  def {EVENT_MODE}(self,server,mset,user,target,modes,args):
    pass
"""
