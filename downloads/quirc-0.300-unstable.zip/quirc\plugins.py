#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#

# Adopted from https://www.guidodiepen.nl/2019/02/implementing-a-simple-plugin-framework-in-python/

import inspect
import os
import pkgutil
import random
import string

from quirc.common import *

class Plugin(object):
	"""Base class that each plugin must inherit from. within this class
	you must define the methods that all of your plugins must implement
	"""

	def __init__(self):
		self._irc = None
		self._gui = None

	def _setIrc(self,obj):
		self._irc = obj

	def _setGui(self,obj):
		self._gui = obj

	def msg(self,target,text):

		try:
			x = self.silent
		except AttributeError:
			self.silent = False

		if self._irc!= None:
			self._irc.msg(target,text)
			if not self.silent:
				d = chat_display(self._irc.nickname,text,MAX_USERNAME_SIZE,True,self._gui.display['self'],self._gui.display['text'],self._gui.display['background'])
				self._gui.writeToChatWindow(self._irc.id,target,d)


	def notice(self,target,text):

		try:
			x = self.silent
		except AttributeError:
			self.silent = False

		if self._irc!= None:
			self._irc.notice(target,text)
			if not self.silent:
				d = notice_display(self._irc.nickname,text,MAX_USERNAME_SIZE,True,self._gui.display['self'],self._gui.display['text'],self._gui.display['background'])
				self._gui.writeToChatWindow(self._irc.id,target,d)

	def action(self,target,text):

		try:
			x = self.silent
		except AttributeError:
			self.silent = False

		if self._irc!= None:
			self._irc.describe(target,text)
			if not self.silent:
				d = action_display(self._irc.nickname,True,self._gui.display['action'],self._gui.display['background'])
				self._gui.writeToChatWindow(self._irc.id,target,d)

	def join(self,channel,key=None):
		if self._irc!= None: self._irc.join(channel,key)

	def part(self,channel,msg=None):
		if self._irc!= None: self._irc.part(channel,msg)

	def send(self,msg):
		if self._irc!= None: self._irc.sendLine(msg)

	def kick(self,channel,user,reason=None):
		if self._irc!= None: self._irc.kick(channel,user,reason)

	def invite(self,user,channel):
		if self._irc!= None: self._irc.invite(user,channel)

	def topic(self,channel,topic):
		if self._irc!= None: self._irc.topic(channel,topic)

	def setMode(self,target,modes):
		if self._irc!= None: self._irc.mode(target,True,modes)

	def unsetMode(self,target,modes):
		if self._irc!= None: self._irc.mode(target,False,modes)

	def nick(self,newnick):
		if self._irc!= None: self._irc.setNick(newNick)

	def quit(self,message=''):
		if self._irc!= None: self._irc.quit(message)

	# GUI methods

	def print(self,text,window=None):

		try:
			x = self.silent
		except AttributeError:
			self.silent = False

		if self.silent: return

		if not window:
			self._gui.printToActiveWindow(text)
			return
		if window.lower() == "all":
			self._gui.writeToAllExisting(text)
			return
		if window.lower() == "log":
			self._gui.writeToLog(text)
			return

	def away(self,server,message=None):
		if self._irc!= None:
			self._irc.away(message)
			self._gui.setToAway(server,message)

	def back(self,server):
		if self._irc!= None:
			self._irc.back()
			self._gui.setToBack(server)



def validatePlugin(p):

	errors = []

	# Check for .name
	try:
		x = p().name
	except AttributeError:
		errors.append("missing .name attribute")

	# Check for .version
	try:
		x = p().version
	except AttributeError:
		errors.append("missing .version attribute")

	# Check for .description
	try:
		x = p().description
	except AttributeError:
		errors.append("missing .description attribute")

	hastag = True
	# Check for ._tag
	try:
		x = p()._tag
	except AttributeError:
		hastag = False

	if hastag:
		errors.append("._tag can't be used as an attribute name")

	# Return any errors
	return errors

def generateTag(tlength=32):
	letters = string.ascii_letters + string.digits
	return ''.join(random.choice(letters) for i in range(tlength))

class PluginCollection(object):

	def __init__(self, plugin_package):
		self.plugin_package = plugin_package
		self.reload_plugins()


	def reload_plugins(self):
		self.plugins = []
		self.seen_paths = []
		self.errors = []
		self.walk_package(self.plugin_package)

	def walk_package(self, package):
		imported_package = __import__(package, fromlist=['blah'])

		for _, pluginname, ispkg in pkgutil.iter_modules(imported_package.__path__, imported_package.__name__ + '.'):
			if not ispkg:
				plugin_module = __import__(pluginname, fromlist=['blah'])
				clsmembers = inspect.getmembers(plugin_module, inspect.isclass)
				for (_, c) in clsmembers:
					if issubclass(c, Plugin) & (c is not Plugin):
						e = validatePlugin(c)
						if len(e)==0:
							plugin = c()

							pm = c.__module__.split(".")
							pm.pop(0)
							plugin.__file__ = inspect.getfile(c).replace(".pyc",".py")
							plugin._package = ".".join(pm)
							plugin._class = f"{c.__name__}"
							plugin.host = ""
							plugin.port = 0
							plugin._tag = generateTag()

							self.plugins.append(plugin)
						else:
							ee = [ inspect.getfile(c).replace(".pyc",".py"), f"{c.__module__}.{c.__name__}" ]
							for er in e:
								ee.append(er)
							self.errors.append(ee)

		all_current_paths = []
		if isinstance(imported_package.__path__, str):
			all_current_paths.append(imported_package.__path__)
		else:
			all_current_paths.extend([x for x in imported_package.__path__])

		for pkg_path in all_current_paths:
			if pkg_path not in self.seen_paths:
				self.seen_paths.append(pkg_path)

				child_pkgs = [p for p in os.listdir(pkg_path) if os.path.isdir(os.path.join(pkg_path, p))]

				for child_pkg in child_pkgs:
					self.walk_package(package + '.' + child_pkg)
