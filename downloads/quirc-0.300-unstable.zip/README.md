# Quirc 0.300

[Download Quirc 0.300 (unstable) here](https://github.com/nutjob-laboratories/quirc/raw/master/quirc-0.300-unstable.zip)

**Quirc** is an open source [Internet relay chat](https://en.wikipedia.org/wiki/Internet_Relay_Chat) client. The current development version is **0.300**.

**Quirc** is being actively developed. Although it is missing some features, it is functional at the moment, and can be used for chatting.

**Quirc** is pronounced /kwərk/, just like the word [quirk](https://www.dictionary.com/browse/quirk).

## Features

* Multi-server
* Intuitive, MDI interface (much like mIRC)
* Automatic channel and private message logging
* A powerful plugin architecture (plugins are written in Python3, just like Quirc)
* A built-in code editor
* Open source (GPL3)

## Requirements
**Quirc** requires Python 3, Qt5, Twisted, and qt5reactor. Qt5 and Twisted can be installed by downloading and installing the software from their respected websites, or by using [**pip**](https://pypi.org/project/pip/):

    pip install pyqt5
    pip install Twisted
    pip install qt5reactor

To connect to IRC servers via SSL, two additional libraries are needed:

    pip install pyOpenSSL
    pip install service_identity

**Quirc** is being developed with Python 3.7.

## Developing **Quirc**

Note: *All development for **Quirc** is done on Windows. There is no reason why it shouldn't run on any non-Windows operating system, but this is untested. All scripts included for development will run only on Windows, by design.*

The batch file in the root directory, `compile_resources.bat`, bundles all the images in `/resources` into a single file, `/quirc/resources.py`.

The official **Quirc** repository is on [GitHub](https://github.com/nutjob-laboratories/quirc).
