#
#  Quirc IRC Client
#  Copyright (C) 2019  Daniel Hetrick
#               _   _       _                         
#              | | (_)     | |                        
#   _ __  _   _| |_ _  ___ | |__                      
#  | '_ \| | | | __| |/ _ \| '_ \                     
#  | | | | |_| | |_| | (_) | |_) |                    
#  |_| |_|\__,_|\__| |\___/|_.__/ _                   
#  | |     | |    _/ |           | |                  
#  | | __ _| |__ |__/_  _ __ __ _| |_ ___  _ __ _   _ 
#  | |/ _` | '_ \ / _ \| '__/ _` | __/ _ \| '__| | | |
#  | | (_| | |_) | (_) | | | (_| | || (_) | |  | |_| |
#  |_|\__,_|_.__/ \___/|_|  \__,_|\__\___/|_|   \__, |
#                                                __/ |
#                                               |___/ 
#  https://github.com/nutjob-laboratories
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from collections import defaultdict

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore

SSL_IS_AVAILABLE = True

try:
	from twisted.internet import ssl
except ImportError as error:
	# Output expected ImportErrors.
	print(error.__class__.__name__ + ": " + error.message)
	SSL_IS_AVAILABLE = False
except Exception as exception:
	# Output unexpected Exceptions.
	print(exception, False)
	print(exception.__class__.__name__ + ": " + exception.message)
	SSL_IS_AVAILABLE = False

from quirc.irc import connect,connectSSL,reconnect,reconnectSSL
from quirc.uptime import UptimeHeartbeat

import quirc.gui.window as Window

import quirc.gui.editor as EditorWindow
import quirc.gui.find as FindWindow

import quirc.gui.dialogs.connect as ConnectDialog
import quirc.gui.dialogs.networks as NetworkDialog
import quirc.gui.dialogs.join as JoinDialog
import quirc.gui.dialogs.nick as NickDialog
import quirc.gui.dialogs.user as UserDialog

from quirc.plugins import PluginCollection

from quirc.common import *

class QuricGUI(QMainWindow):

	"""The GUI class for the main client.
	"""

	def __init__(self,app,parent=None):
		super(QuricGUI, self).__init__(parent)

		self.app = app
		self.parent = parent

		self.disconnected_on_purpose = False

		# Setting defaults
		self.nickname = DEFAULT_NICKNAME
		self.username = DEFAULT_USERNAME
		self.realname = DEFAULT_IRCNAME

		# Start the uptime counter
		self.uptime = 0
		self.uptimeTimer = UptimeHeartbeat(self)
		self.uptimeTimer.beat.connect(self.heartbeat)
		self.uptimeTimer.start()

		# Define attributes for later use

		self.connections = {}				# Where IRC server connections are stored
		self.windows = defaultdict(list)	# Where windows are stored
		self.toolbars = {}					# Stores server toolbars
		self.timers = {}					# Stores server timers
		self.plaintext = {}             	# Plain chat (non-html) storage
		self.windowcount = 0

		# Load in settings from files

		self.display = loadDisplay()

		# self.font = QFont(self.display["font"],self.display["fontsize"])
		# self.fontBold = QFont(self.display["font"],self.display["fontsize"],QFont.Bold)
		# self.fontitalic = QFont(self.display["font"],self.display["fontsize"])
		# self.fontitalic.setItalic(True)

		f = QFont()
		f.fromString(self.display["font"])
		self.font = f

		f = QFont()
		f.fromString(self.display["font"])
		self.fontBold = f
		self.fontBold.setBold(True)

		f = QFont()
		f.fromString(self.display["font"])
		self.fontitalic = f
		self.fontitalic.setItalic(True)

		f = QFont()
		f.fromString(self.display["font"])
		self.fontUsers = f
		self.fontUsers.setBold(True)
		self.fontUsers.setPointSize(self.fontUsers.pointSize()+ADDITIONAL_POINT_SIZE_FOR_USER_DISPLAY)

		app.setFont(self.font)

		self.displayTimestamp = True
		self.displayUptime = True
		self.doReconnect = True
		self.keepAlive = True
		self.openWindowOnIncomingPrivate = True
		self.joinInvite = False

		self.initialWindowWidth = 500
		self.initialWindowHeight = 350

		self.settings = loadSettings()

		self.displayTimestamp = self.settings["timestamp"]
		self.displayUptime = self.settings["uptime"]
		self.doReconnect = self.settings["reconnect"]
		self.keepAlive = self.settings["keepalive"]
		self.joinInvite = self.settings["invite"]
		self.openWindowOnIncomingPrivate = self.settings["private"]
		self.initialWindowWidth = self.settings["iwidth"]
		self.initialWindowHeight = self.settings["iheight"]

		# Load plugins
		self.packages = PluginCollection('plugins')

		# Add GUI reference to all plugins
		for plugin in self.packages.plugins:
			plugin._setGui(self)
			# Load in event_load
			event = getattr(plugin, EVENT_LOAD, None)
			if callable(event):
				event()

		# Build the UI
		self.buildUI()

	def buildUI(self):
		"""Builds the GUI for Quirc.
		"""

		self.setWindowTitle(f"{APPLICATION_NAME}")
		self.setWindowIcon(QIcon(QUIRC_ICON))

		# Create the MDI widget
		self.MDI = QMdiArea()
		self.setCentralWidget(self.MDI)

		pix = QPixmap(MDI_BACKGROUND)
		backgroundBrush = QBrush(pix)
		self.MDI.setBackground(backgroundBrush)

		# Create master log
		self.log = self.buildDockLog()
		self.addDockWidget(Qt.BottomDockWidgetArea,self.log)

		# Add background image to log.
		css = "QTextEdit { background-image: url(:/logbg.png); background-attachment: fixed; background-repeat: no-repeat; background-position: right; "
		css = css + f"background-color: {self.display['background']}; color: {self.display['text']};"
		css = css + " }"
		self.logTxt.setStyleSheet(css)

		# Write banner to log
		img = QImage(QUIRC_SMALL_LOGO)
		cursor = QTextCursor(self.logTxt.document())
		cursor.insertImage(img)
		self.writeToLog(f"<b><a href=\"https://github.com/nutjob-laboratories/quirc\">https://github.com/nutjob-laboratories/quirc</a><b>")

		# Creates the master menu
		menubar = self.menuBar()

		ircMenu = menubar.addMenu(f"IRC")

		self.actConnect = QAction(QIcon(SERVER_ICON),"Connect to Server",self)
		self.actConnect.triggered.connect(self.doConnectDialog)
		ircMenu.addAction(self.actConnect)

		self.actNetwork = QAction(QIcon(NETWORK_ICON),"Connect to Network",self)
		self.actNetwork.triggered.connect(self.doNetworkDialog)
		ircMenu.addAction(self.actNetwork)

		self.actDisconnect = QAction(QIcon(DISCONNECT_ICON),"Disconnect",self)
		self.actDisconnect.triggered.connect(self.selectDisconnect)
		ircMenu.addAction(self.actDisconnect)
		self.actDisconnect.setEnabled(False)

		ircMenu.addSeparator()

		actExit = QAction(QIcon(EXIT_ICON),"Exit",self)
		actExit.triggered.connect(self.close)
		ircMenu.addAction(actExit)

		optMenu = menubar.addMenu("Options")

		self.actUser = QAction(QIcon(USER_ICON),"Edit user information",self)
		self.actUser.triggered.connect(self.doUserDialog)
		optMenu.addAction(self.actUser)

		self.optFont = QAction(QIcon(FONT_ICON),"Set font",self)
		self.optFont.triggered.connect(self.getFont)
		optMenu.addAction(self.optFont)

		pf = self.display["font"].split(',')
		mf = pf[0]
		ms = pf[1]
		self.optFont.setText(f"Set font ({mf}, {ms}pt)")

		optMenu.addSeparator()

		actLog = self.log.toggleViewAction()
		actLog.setText("Log visible")
		optMenu.addAction(actLog)

		optAlive = QAction("Keep connection alive",self,checkable=True)
		optAlive.setChecked(self.keepAlive)
		optAlive.triggered.connect(self.toggleAlive)
		optMenu.addAction(optAlive)

		optRecon = QAction("Reconnect on disconnect",self,checkable=True)
		optRecon.setChecked(self.doReconnect)
		optRecon.triggered.connect(self.toggleReconnect)
		optMenu.addAction(optRecon)

		optUptime = QAction("Display server uptime",self,checkable=True)
		optUptime.setChecked(self.displayUptime)
		optUptime.triggered.connect(self.toggleUptime)
		optMenu.addAction(optUptime)

		optUptime = QAction("Display timestamps",self,checkable=True)
		optUptime.setChecked(self.displayTimestamp)
		optUptime.triggered.connect(self.toggleTimestamp)
		optMenu.addAction(optUptime)

		optInvite = QAction("Automatic join on channel invite",self,checkable=True)
		optInvite.setChecked(self.joinInvite)
		optInvite.triggered.connect(self.toggleInvite)
		optMenu.addAction(optInvite)

		optPrivate = QAction("Open windows for incoming private messages",self,checkable=True)
		optPrivate.setChecked(self.openWindowOnIncomingPrivate)
		optPrivate.triggered.connect(self.togglePrivateWindow)
		optMenu.addAction(optPrivate)

		self.pluginmenu = menubar.addMenu("Plugins")

		self.pluginmenu.setToolTipsVisible(True)

		self.buildPluginMenu()

		self.windowMenu = menubar.addMenu("Windows")

		self.rebuildWindowMenu()
	
	# HELPER FUNCTIONS

	def selectDisconnect(self):
		servers = []
		ids = []
		for w in self.connections: 
			servers.append(self.connections[w].nickname+" on "+self.connections[w].hostname)
			ids.append(w)

		print(ids)

		# If there's only one connection active, disconnect it
		if len(servers)==1:
			self.disconnected_on_purpose = True
			self.connections[ids[0]].quit()
			return

		item, okPressed = QInputDialog.getItem(self,"Select Connection","Which server to disconnect from?",servers,0,False)
		if okPressed and item:
			self.disconnected_on_purpose = True
			#self.connections[ids[int(item)]].quit()
			c = 0
			for i in servers:
				if i==item:
					self.connections[ids[c]].quit()
					continue
				c = c + 1
			self.rebuildWindowMenu()

	def connectToIRC(self,connection_info,sreconnect=False):

		sreconnect = self.doReconnect

		nick = connection_info[0]
		username = connection_info[1]
		realname = connection_info[2]
		host = connection_info[3]
		port = connection_info[4]
		password = connection_info[5]
		use_ssl = connection_info[6]

		if use_ssl==1:
			use_ssl = True
		else:
			use_ssl = False

		# Sanity check
		errs = []
		if len(nick)==0: errs.append("nickname not entered")
		if len(username)==0: errs.append("username not entered")
		if len(realname)==0: errs.append("real name not entered")
		if len(host)==0: errs.append("host not entered")
		if len(port)==0: errs.append("port not entered")
		if not is_integer(port): errs.append(f"invalid port \"{port}\"")
		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(QUIRC_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Can't connect to IRC")
			msg.exec_()
			return

		port = int(port)

		# Save server information
		if use_ssl:
			save_last_server( host, port, password, True )
		else:
			save_last_server( host, port, password, False )

		# Save user information
		user = {
			"nick": str(nick),
			"username": str(username),
			"realname": str(realname)
		}
		save_user(user)

		self.nickname = nick
		self.username = username
		self.realname = realname

		#sid = f"{host}:{str(port)}"

		if not use_ssl:
			if sreconnect:
				reconnect(host,port,nick,username,realname,self,password)
			else:
				connect(host,port,nick,username,realname,self,password)
		else:
			if sreconnect:
				reconnectSSL(host,port,nick,username,realname,self,password)
			else:
				connectSSL(host,port,nick,username,realname,self,password)


	def heartbeat(self):
		self.uptime = self.uptime + 1

		y = 0
		for w in self.connections:
			for x in self.windows[w]: y = y + 1

		if y!=self.windowcount: self.rebuildWindowMenu()

		# Execute event
		for plugin in self.packages.plugins:
			event = getattr(plugin, EVENT_TICK, None)
			if callable(event):
				# plugin._setIrc(self.connections[serverid])
				for c in self.connections:
					plugin._setIrc(self.connections[c])
					event(c,self.uptime)

	def servBeat(self,serverid):

		if not self.toolbars[serverid]: return

		if not self.displayUptime: return

		self.toolbars[serverid].stimecount = self.toolbars[serverid].stimecount + 1

		t = convertSeconds(self.toolbars[serverid].stimecount)
		hours = t[0]
		if len(str(hours))==1: hours = f"0{hours}"
		minutes = t[1]
		if len(str(minutes))==1: minutes = f"0{minutes}"
		seconds = t[2]
		if len(str(seconds))==1: seconds = f"0{seconds}"
		display = f"{hours}:{minutes}:{seconds}"

		self.toolbars[serverid].stimer.setText(display)

	def closeEvent(self, event):

		# Close all windows
		for w in self.windows:
			for i in self.windows[w]:
				i.subwindow.close()
				i.window.close()

		self.uptimeTimer.stop()

		# Execute plugin events
		for plugin in self.packages.plugins:
			event = getattr(plugin, EVENT_UNLOAD, None)
			if callable(event):
				event()

		self.app.quit()

	def printToActiveWindow(self,txt):
		activeSubWindow = self.MDI.activeSubWindow()
		if activeSubWindow:
			x = activeSubWindow.widget()
			x.writeText(txt)

	def writeToChatWindow(self,serverid,target,text):
		for w in self.windows[serverid]:
			if w.window.name == target:
				w.window.writeText(text)

	def writeToAll(self,serverid,text):
		for w in self.windows[serverid]:
			w.window.writeText(text)

	def writeToAllExisting(self,text):
		for c in self.connections:
			for w in self.windows[c]:
				w.window.writeText(text)

	def writeToLog(self,text):
		self.logTxt.append(text)
		self.logTxt.moveCursor(QTextCursor.End)

	def setToAway(self,serverid,msg=None):
		for w in self.windows[serverid]:
			w.window.setAway(msg)

	def setToBack(self,serverid):
		for w in self.windows[serverid]:
			w.window.setBack()

	def destroyWindow(self,serverid,name):
		cleaned = []
		for w in self.windows[serverid]:
			if w.window.name == name: continue
			cleaned.append(w)
		self.windows[serverid] = cleaned

	def buildDockLog(self):

		width = self.width()
		height = self.height() * 0.28

		class LogWidget(QTextBrowser):

			def __init__(self,parent=None):
				self.started = True
				super(LogWidget, self).__init__(parent)

			def sizeHint(self):
				if self.started:
					self.started = False
					return QtCore.QSize(width, height)
				return QTextBrowser.sizeHint()

		self.logTxt = LogWidget(self)
		self.logTxt.anchorClicked.connect(self.linkClicked)

		dock = QDockWidget(self)
		dock.setWidget(self.logTxt)
		dock.setFloating(False)

		dock.setFeatures( QDockWidget.DockWidgetVerticalTitleBar | QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetFloatable )

		return dock

	# If users click on URLs, they will open in the default browser
	def linkClicked(self,url):
		if url.host():
			QDesktopServices.openUrl(url)
			self.logTxt.setSource(QUrl())
			self.logTxt.moveCursor(QTextCursor.End)
		else:
			link = url.toString()
			d = decodeWindowLink(link)
			user = d[1]
			sid = d[0]

			self.createUserWindow(sid,user)

			self.logTxt.setSource(QUrl())
			self.logTxt.moveCursor(QTextCursor.End)

	def buildServerToolbar(self,serverid):
		servbar = QToolBar(self)
		self.addToolBar(Qt.TopToolBarArea,servbar)
		servbar.setIconSize(QSize(16,16))
		servbar.setFloatable(True)
		servbar.setAllowedAreas( Qt.TopToolBarArea | Qt.BottomToolBarArea )

		servServerIcon = QLabel()
		servServerIcon.setPixmap( QIcon(SERVER_ICON).pixmap(16,16) )
		servbar.addWidget(servServerIcon)
		servServerIcon.setFixedHeight(TOOLBAR_BUTTON_HEIGHT)

		servbar.addWidget(QLabel(" "))
		

		serverhost = self.connections[serverid].hostname
		servbar.addWidget(QLabel(f"<b>{serverhost}</b>"))

		servbar.addWidget(QLabel(" "))

		servbar.addSeparator()

		buttonNick = QPushButton()
		buttonNick.setIcon(QIcon(USER_ICON))
		buttonNick.setToolTip("Change Nickname")
		buttonNick.clicked.connect(lambda state,serv=serverid: self.doNickChange(serv))
		servbar.addWidget(buttonNick)
		buttonNick.setFixedHeight(TOOLBAR_BUTTON_HEIGHT)

		servbar.addWidget(QLabel(" "))

		n = self.connections[serverid].nickname
		#while len(n)<MAX_USERNAME_SIZE: n = n +" "
		n = n + ("&nbsp;"*(MAX_USERNAME_SIZE-len(n)))

		servbar.nickname = QLabel(f"<b>{n}</b>")
		servbar.addWidget(servbar.nickname)

		servbar.addWidget(QLabel(" "))

		servbar.addSeparator()

		buttonKey = QPushButton()
		buttonKey.setIcon(QIcon(LOCKED_ICON))
		buttonKey.setToolTip("Join Channel With Key")
		buttonKey.clicked.connect(lambda state,serv=serverid: self.doToolbarJoinKey(serv))
		servbar.addWidget(buttonKey)
		buttonKey.setFixedHeight(TOOLBAR_BUTTON_HEIGHT)

		buttonJoin = QPushButton("Join")
		buttonJoin.clicked.connect(lambda state,serv=serverid,obj=servbar: self.doChannelJoin(serv,obj))
		buttonJoin.setFixedWidth(50)
		buttonJoin.setFixedHeight(TOOLBAR_BUTTON_HEIGHT)

		servbar.channel = QLineEdit("")
		servbar.channel.setFixedWidth(150)

		servbar.addWidget(buttonJoin)
		servbar.addWidget(QLabel(" "))
		servbar.addWidget(servbar.channel)

		spacer = QWidget()
		spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
		servbar.addWidget(spacer)

		if self.displayUptime:
			servbar.stimer = QLabel("00:00:00")
		else:
			servbar.stimer = QLabel(" ")
		servbar.stimer.setFont(self.fontBold)

		servbar.stimecount = 0
		servbar.addWidget(servbar.stimer)
		servbar.addWidget(QLabel(" "))

		buttonDisco = QPushButton()
		buttonDisco.setIcon(QIcon(TOOLBAR_DISCONNECT_ICON))
		buttonDisco.setToolTip(f"Disconnect from {serverhost}")
		buttonDisco.clicked.connect(lambda state,serv=serverid: self.doToolbarDisconnect(serv))
		servbar.addWidget(buttonDisco)
		buttonDisco.setFixedHeight(TOOLBAR_BUTTON_HEIGHT)

		# Stack toolbars if there's more than one
		self.addToolBarBreak(Qt.TopToolBarArea)

		return servbar

	def doToolbarDisconnect(self,serverid):
		
		self.disconnected_on_purpose = True
		self.connections[serverid].quit()

	def doToolbarJoinKey(self,serverid):
		x = JoinDialog.Dialog()
		channel_info = x.get_channel_information(parent=self)

		# User cancled dialog
		if not channel_info: return

		channel = channel_info[0]
		password = channel_info[1]

		if channel.isspace() or len(channel)==0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(QUIRC_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("No channel entered")
			msg.setWindowTitle("Error")
			msg.exec_()
			return

		if password.isspace() or len(password)==0:
			self.connections[serverid].join(channel)
		else:
			self.connections[serverid].join(channel,password)

	def doChannelJoin(self,serverid,toolbar):

		chan = toolbar.channel.text()
		if len(chan)>0:
			if chan[0]=="#":
				self.connections[serverid].join(chan)
			else:
				chan = "#" + chan
				self.connections[serverid].join(chan)
			toolbar.channel.setText('')

	def doNickChange(self,serverid):

		x = NickDialog.Dialog()
		newnick = x.get_nick_information(parent=self)

		# User cancled dialog
		if not newnick: return

		if newnick.isspace() or len(newnick)==0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(QUIRC_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("No nick entered")
			msg.setWindowTitle("Error")
			msg.exec_()
			return

		oldnick = self.nickname

		self.connections[serverid].setNick(newnick)

	def doUserDialog(self):

		x = UserDialog.Dialog()
		user = x.get_user_information(parent=self)

		if not user: return

		nick = user[0]
		username = user[1]
		realname = user[2]

		errs = []
		if len(nick)==0: errs.append("nickname not entered")
		if len(username)==0: errs.append("username not entered")
		if len(realname)==0: errs.append("real name not entered")
		if len(errs)>0:
			msg = QMessageBox()
			msg.setWindowIcon(QIcon(QUIRC_ICON))
			msg.setIcon(QMessageBox.Critical)
			msg.setText("Missing or Invalid Input")
			es = ""
			for e in errs: es = es + f"<li>{e}</li>"
			msg.setInformativeText(f"<ul>{es}</ul>")
			msg.setWindowTitle("Faulty user information")
			msg.exec_()
			return

		si = {
			"nick": nick,
			"username": username,
			"realname": realname
		}

		save_user(si)

	# MENU FUNCTIONS

	def togglePrivateWindow(self):
		if self.openWindowOnIncomingPrivate:
			self.openWindowOnIncomingPrivate = False
		else:
			self.openWindowOnIncomingPrivate = True

		self.settings["private"] = self.openWindowOnIncomingPrivate
		saveSettings(self.settings)

	def getFont(self):
		font, ok = QFontDialog.getFont()
		if ok:

			self.setNewFont(font.toString())

			pf = self.display["font"].split(',')
			mf = pf[0]
			ms = pf[1]
			self.optFont.setText(f"Set font ({mf}, {ms}pt)")

	def toggleInvite(self):

		if self.joinInvite:
			self.joinInvite = False
		else:
			self.joinInvite = True

		self.settings["invite"] = self.joinInvite
		saveSettings(self.settings)

	def toggleAlive(self):
		if self.keepAlive:
			self.keepAlive = False
			for s in self.connections:
				if not self.connections[s].alive: continue
				self.connections[s].alive = False
				self.connections[s].stopHeartbeat()
		else:
			self.keepAlive = True
			for s in self.connections:
				if self.connections[s].alive: continue
				self.connections[s].alive = True
				self.connections[s].startHeartbeat()

		self.settings["keepalive"] = self.keepAlive
		saveSettings(self.settings)

	def toggleReconnect(self):
		if self.doReconnect:
			self.doReconnect = False
		else:
			self.doReconnect = True

		self.settings["reconnect"] = self.doReconnect
		saveSettings(self.settings)

	def toggleUptime(self):
		if self.displayUptime:
			self.displayUptime = False
			for s in self.toolbars:
				self.toolbars[s].stimer.setText('')
		else:
			self.displayUptime = True
			for s in self.toolbars:
				self.toolbars[s].stimer.setText('00:00:00')

		self.settings["uptime"] = self.displayUptime
		saveSettings(self.settings)

	def toggleTimestamp(self):
		if self.displayTimestamp:
			self.displayTimestamp = False
			for s in self.connections:
				for w in self.windows[s]:
					w.window.displayTimestamp = False
					w.window.showTimestampSetting()
		else:
			self.displayTimestamp = True
			for s in self.connections:
				for w in self.windows[s]:
					w.window.displayTimestamp = True
					w.window.showTimestampSetting()

		self.settings["timestamp"] = self.displayTimestamp
		saveSettings(self.settings)

	def rebuildWindowMenu(self):
		self.windowMenu.clear()

		actCascade = QAction(QIcon(CASCADE_ICON),"Cascade Windows",self)
		actCascade.triggered.connect(lambda state: self.MDI.cascadeSubWindows())
		self.windowMenu.addAction(actCascade)

		actTile = QAction(QIcon(TILE_ICON),"Tile Windows",self)
		actTile.triggered.connect(lambda state: self.MDI.tileSubWindows())
		self.windowMenu.addAction(actTile)

		self.windowMenu.addSeparator()

		self.windowcount = 0
		for w in self.connections:
			serverhost = self.connections[w].hostname
			servMenu = self.windowMenu.addMenu(QIcon(SERVER_ICON),f"{serverhost}")
			for x in self.windows[w]:
				if x.window.is_channel:
					win = QAction(QIcon(CHANNEL_WINDOW_ICON),x.window.name,self)
					self.windowcount = self.windowcount + 1
				else:
					win = QAction(QIcon(USER_WINDOW_ICON),x.window.name,self)
					self.windowcount = self.windowcount + 1
				win.triggered.connect(lambda state: x.window.showNormal())
				servMenu.addAction(win)


	def doConnectDialog(self):
		
		# Show dialog, and get information from the user
		x = ConnectDialog.Dialog(SSL_IS_AVAILABLE,parent=self)
		connection_info = x.get_connect_information(SSL_IS_AVAILABLE,parent=self)

		# User cancled dialog
		if not connection_info: return

		self.connectToIRC(connection_info)

	def doNetworkDialog(self):
		
		# Show dialog, and get information from the user
		x = NetworkDialog.Dialog(SSL_IS_AVAILABLE,parent=self)
		connection_info = x.get_connect_information(SSL_IS_AVAILABLE,parent=self)

		# User cancled dialog
		if not connection_info: return

		self.connectToIRC(connection_info)

	# IRC EVENTS

	def renamed(self,serverid,nick,oldnick):
		n = nick + ("&nbsp;"*(MAX_USERNAME_SIZE-len(nick)))

		self.toolbars[serverid].nickname.setText(f"<b>{n}</b>")

		for w in self.windows[serverid]:
			w.window.nickname = nick
			if w.window.is_channel:
				items = w.window.channelUserDisplay.findItems(f"*{oldnick}",Qt.MatchWildcard)

				if len(items) > 0:
					for item in items:
						t = item.text()
						if len(t)>0 and t[0]=="@":
							item.setText(f"@{nick}")
							continue
						elif len(t)>0 and t[0]=="+":
							item.setText(f"+{nick}")
							continue
						else:
							item.setText(nick)

		d = systemTextDisplay(f"You are now known as \"{nick}\"",self.display["system"],self.display["background"])
		self.writeToLog(d)
		self.writeToAll(serverid,d)

	def connect(self,serverid,obj):

		# Store the connection
		self.connections[serverid] = obj
		serverhost = self.connections[serverid].hostname

		self.timers[serverid] = UptimeHeartbeat(self)
		self.timers[serverid].beat.connect(lambda serverid=serverid: self.servBeat(serverid))

		# Display to the user that we're connected
		d = systemTextDisplay(f"Connecting to {serverhost}...",self.display["system"],self.display["background"])
		self.writeToLog(d)

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_CONNECTED, None)
			if callable(event):
				event(serverid)

	def disconnect(self,serverid,reason):

		serverhost = self.connections[serverid].hostname

		# Execute plugin events
		if "closed clean" in f"{reason}":
			reason = "Quit IRC"
		else:
			reason = "Connection error"

		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_DISCONNECTED, None)
			if callable(event):
				event(serverid,reason)

		if self.connections[serverid].alive:
			self.connections[serverid].stopHeartbeat()

		# Delete the stored connection
		del self.connections[serverid]

		# Close all windows associated with the connection
		for w in self.windows[serverid]:
			w.subwindow.close()
			w.window.close()

		# Delete stored windows
		del self.windows[serverid]

		if "closed clean" in f"{reason}":
			d = systemTextDisplay(f"Disconnected from {serverhost}.",self.display["system"],self.display["background"])
		else:
			d = systemTextDisplay(f"Disconnected from {serverhost}: {reason}",self.display["system"],self.display["background"])
		self.writeToLog(d)

		# Disable "Disconnect" menu item if there's no active connections
		if len(self.connections)==0:
			self.actDisconnect.setEnabled(False)

		self.timers[serverid].stop()	# Stop the server uptime counter
		self.timers[serverid] = None

		# Destroy server toolbar
		self.toolbars[serverid].close()
		self.toolbars[serverid] = None
		
	def registered(self,serverid):

		#serverhost = self.connections[serverid].hostname
		serverhost = self.connections[serverid].host + ":" + str(self.connections[serverid].port)

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_REGISTERED, None)
			if callable(event):
				event(serverid)

		# We're connected, so make the "Disconnect" menu item enabled
		self.actDisconnect.setEnabled(True)

		d = systemTextDisplay(f"Registered with {serverhost}!",self.display["system"],self.display["background"])
		self.writeToLog(d)

		autojoins = get_autojoins(self.connections[serverid].host)
		for c in autojoins:
			p = c.split(AUTOJOIN_DELIMITER)
			if len(p)==2:
				# got a key
				self.connections[serverid].join(p[0],p[1])
			else:
				self.connections[serverid].join(c)

		self.timers[serverid].start()	# Start the server uptime counter

		self.toolbars[serverid] = self.buildServerToolbar(serverid)

		if self.keepAlive:
			self.connections[serverid].alive = True
			self.connections[serverid].startHeartbeat()
		else:
			self.connections[serverid].alive = False

	def joined(self,serverid,channel):

		# Create the channel window, store it, and show it
		chanWindow = Window.createNew(channel,self.connections[serverid],serverid,self.MDI,self)
		self.windows[serverid].append(chanWindow)
		chanWindow.window.show()

		d = systemTextDisplay(f"Joined {channel}.",self.display["system"],self.display["background"])
		self.writeToChatWindow(serverid,channel,d)

		self.rebuildWindowMenu()

	def channelNames(self,serverid,channel,users):

		for w in self.windows[serverid]:
			if w.window.name == channel:
				w.window.setUserList(users)

	def publicMessage(self,serverid,channel,user,message):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_PUBLIC, None)
			if callable(event):
				event(serverid,channel,user,message)

		p = user.split("!")
		if len(p)==2: user = p[0]

		d = chat_display(user,message,MAX_USERNAME_SIZE,True,self.display['user'],self.display['text'],self.display['background'])

		self.writeToChatWindow(serverid,channel,d)

	def privateMessage(self,serverid,user,message):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_PRIVATE, None)
			if callable(event):
				event(serverid,user,message)

		p = user.split("!")
		if len(p)==2: user = p[0]

		for w in self.windows[serverid]:
			if w.window.name == user:
				# Window exists
				d = chat_display(user,message,MAX_USERNAME_SIZE,True,self.display['user'],self.display['text'],self.display['background'])
				self.writeToChatWindow(serverid,user,d)
				return

		if self.openWindowOnIncomingPrivate:
			# Window doesn't exist, so create it
			userWindow = Window.createNew(user,self.connections[serverid],serverid,self.MDI,self)
			self.windows[serverid].append(userWindow)
			userWindow.window.show()

			# Write to it
			d = chat_display(user,message,MAX_USERNAME_SIZE,True,self.display['user'],self.display['text'],self.display['background'])
			self.writeToChatWindow(serverid,user,d)

			self.rebuildWindowMenu()
		else:
			link = encodeWindowLink(serverid,user)
			d = log_chat_display(f"<b>[{serverid}] <a href=\"{link}\">{user}</a></b>",message,MAX_USERNAME_SIZE,True,self.display['user'],self.display['text'],self.display['background'])
			self.writeToLog(d)

	def createUserWindow(self,serverid,user):
		for w in self.windows[serverid]:
			if w.window.name == user:
				return
		userWindow = Window.createNew(user,self.connections[serverid],serverid,self.MDI,self)
		self.windows[serverid].append(userWindow)
		userWindow.window.show()

	def noticeMessage(self,serverid,channel,user,message):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_NOTICE, None)
			if callable(event):
				event(serverid,channel,user,message)

		p = user.split("!")
		if len(p)==2: user = p[0]

		is_channel = True
		if len(channel)>1 and channel[0]!="#": is_channel = False

		if is_channel:
			for w in self.windows[serverid]:
				if w.window.name == channel:
					# Window exists
					d = notice_display(user,message,MAX_USERNAME_SIZE,True,self.display['notice'],self.display['text'],self.display['background'])
					self.writeToChatWindow(serverid,channel,d)
					return

		if user=="":
			d = systemTextDisplay(message,self.display["system"],self.display["background"])
		else:
			d = notice_display(user,message,MAX_USERNAME_SIZE,True,self.display['notice'],self.display['text'],self.display['background'])
		self.writeToLog(d)

	def actionMessage(self,serverid,channel,user,message):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_ACTION, None)
			if callable(event):
				event(serverid,channel,user,message)

		p = user.split("!")
		if len(p)==2: user = p[0]

		if channel==self.nickname:
			channel = user

		for w in self.windows[serverid]:
			if w.window.name == channel:
				# Window exists
				d = action_display(user,message,True,self.display['action'],self.display['background'])
				self.writeToChatWindow(serverid,channel,d)
				return

		# Window doesn't exist, so create it
		chatWindow = Window.createNew(channel,self.connections[serverid],serverid,self.MDI,self)
		self.windows[serverid].append(chatWindow)
		chatWindow.window.show()

		# Write to it
		d = action_display(user,message,True,self.display['action'],self.display['background'])
		self.writeToChatWindow(serverid,channel,d)

	def userJoined(self,serverid,user,channel):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_JOIN, None)
			if callable(event):
				event(serverid,channel,user)

		p = user.split("!")
		if len(p)==2: user = p[0]

		for w in self.windows[serverid]:
				if w.window.name == channel:
					d = systemTextDisplay(f"{user} joined {channel}.",self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)
					self.writeToLog(d)

	def userParted(self,serverid,user,channel):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_PART, None)
			if callable(event):
				event(serverid,channel,user)

		p = user.split("!")
		if len(p)==2: user = p[0]

		for w in self.windows[serverid]:
				if w.window.name == channel:
					d = systemTextDisplay(f"{user} left {channel}.",self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)
					self.writeToLog(d)

	def setKey(self,serverid,channel,key):
		for w in self.windows[serverid]:
				if w.window.name == channel:
					w.window.key = key
					w.window.addModes("k")

	def unsetKey(self,serverid,channel):
		for w in self.windows[serverid]:
				if w.window.name == channel:
					w.window.key = ''
					w.window.removeModes("k")

	def mode(self,serverid,user,channel,mset,modes,args):

		if len(modes)<1: return

		args = list(args)

		cleaned = []
		for a in args:
			if a == None: continue
			cleaned.append(a)
		args = cleaned

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_MODE, None)
			if callable(event):
				event(serverid,mset,user,channel,modes,args)

		p = user.split('!')
		if len(p)==2:
			user = p[0]

		reportadd = []
		reportremove = []

		changedUser = False

		for m in modes:

			if m=="k":
				n = args.pop(0)
				if mset:
					if n:
						msg = f"{user} set {channel}'s channel key to \"{n}\""
						self.setKey(serverid,channel,n)
					else:
						msg = ''
				else:
					msg = f"{user} unset {channel}'s channel key"
					self.unsetKey(serverid,channel)
				if len(msg)>0:
					d = systemTextDisplay(msg,self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)
					self.writeToLog(d)
				continue

			if m=="o":
				n = args.pop(0)
				if mset:
					if n:
						msg = f"{user} granted {channel} operator status to {n}"
					else:
						msg = ''
				else:
					if n:
						msg = f"{user} took {channel} operator status from {n}"
					else:
						msg = ''
				if len(msg)>0:
					d = systemTextDisplay(msg,self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)
					#self.connections[serverid].sendLine(f"NAMES {channel}")
					changedUser = True
					self.writeToLog(d)
				continue

			if m=="v":
				n = args.pop(0)
				if mset:
					if n:
						msg = f"{user} granted {channel} voiced status to {n}"
					else:
						msg = ''
				else:
					if n:
						msg = f"{user} took {channel} voiced status from {n}"
					else:
						msg = ''
				if len(msg)>0:
					d = systemTextDisplay(msg,self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)
					#self.connections[serverid].sendLine(f"NAMES {channel}")
					changedUser = True
					self.writeToLog(d)
				continue

			if m=="c":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("c")
							reportadd.append("c")
						else:
							w.window.removeModes("c")
							reportremove.append("c")
				continue

			if m=="C":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("C")
							reportadd.append("C")
						else:
							w.window.removeModes("C")
							reportremove.append("C")
				continue

			if m=="m":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("m")
							reportadd.append("m")
						else:
							w.window.removeModes("m")
							reportremove.append("m")
				continue

			if m=="n":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("n")
							reportadd.append("n")
						else:
							w.window.removeModes("n")
							reportremove.append("n")
				continue

			if m=="p":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("p")
							reportadd.append("p")
						else:
							w.window.removeModes("p")
							reportremove.append("p")
				continue

			if m=="s":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("s")
							reportadd.append("s")
						else:
							w.window.removeModes("s")
							reportremove.append("s")
				continue

			if m=="t":
				for w in self.windows[serverid]:
					if w.window.name == channel:
						if mset:
							w.window.addModes("t")
							reportadd.append("t")
						else:
							w.window.removeModes("t")
							reportremove.append("t")
				continue

			if mset:
				reportadd.append(m)
			else:
				reportremove.append(m)

		if len(reportadd)>0 or len(reportremove)>0:
			if mset:
				d = systemTextDisplay(f"{user} set +{''.join(reportadd)} in {channel}",self.display["system"],self.display["background"])
				self.writeToChatWindow(serverid,channel,d)
			else:
				d = systemTextDisplay(f"{user} set -{''.join(reportremove)} in {channel}",self.display["system"],self.display["background"])
				self.writeToChatWindow(serverid,channel,d)
			self.writeToLog(d)

		if changedUser: self.connections[serverid].sendLine(f"NAMES {channel}")

	def serverMessage(self,serverid,channel,message):
		for w in self.windows[serverid]:
				if w.window.name == channel:
					d = systemTextDisplay(message,self.display["system"],self.display["background"])
					self.writeToChatWindow(serverid,channel,d)

	def ircQuit(self,serverid,user,message):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_QUIT, None)
			if callable(event):
				event(serverid,user,message)

		p = user.split("!")
		if len(p)==2: user = p[0]

		found = []
		for w in self.connections:
			if w != serverid: continue
			for x in self.windows[w]:
				items = x.window.channelUserDisplay.findItems(f"*{user}",Qt.MatchWildcard)

				if len(items) > 0:
					found.append(x.name)

		if message!='':
			d = systemTextDisplay(f"{user} quit IRC ({message}).",self.display["system"],self.display["background"])
		else:
			d = systemTextDisplay(f"{user} quit IRC.",self.display["system"],self.display["background"])

		for chan in found:
			self.writeToChatWindow(serverid,chan,d)
		self.writeToLog(d)

	def topic(self,serverid,user,channel,topic):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_TOPIC, None)
			if callable(event):
				event(serverid,channel,user,topic)

		p = user.split('!')
		if len(p)--2: user = p[0]
		
		for w in self.windows[serverid]:
			if w.window.name == channel:
				if topic != '':
					w.window.setWindowTitle(f"{w.window.name} - {topic}")
					d = systemTextDisplay(f"{user} set the channel topic to \"{topic}\".",self.display["system"],self.display["background"])
				else:
					w.window.setWindowTitle(f"{w.window.name}")
					d = systemTextDisplay(f"{user} set the channel to nothing.",self.display["system"],self.display["background"])
				self.writeToChatWindow(serverid,channel,d)

	def invite(self,serverid,user,channel):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_INVITE, None)
			if callable(event):
				event(serverid,channel,user)

		p = user.split('!')
		if len(p)--2: user = p[0]

		d = systemTextDisplay(f"{user} invited you to {channel}.",self.display["system"],self.display["background"])
		self.writeToAll(serverid,d)
		self.writeToLog(d)

		if self.joinInvite: self.connections[serverid].join(channel)

	def inviting(self,serverid,user,channel):

		p = user.split('!')
		if len(p)--2: user = p[0]

		d = systemTextDisplay(f"Invitation to {channel} sent to {user}.",self.display["system"],self.display["background"])
		self.writeToLog(d)

	def whois(self,serverid,data):

		d = makeWhoisPretty(data)
		d = whois_display(d,MAX_USERNAME_SIZE,self.display["system"],self.display["text"],self.display["background"])
		self.printToActiveWindow(d)

	def motd(self,serverid,motd):

		# Execute plugin events
		for plugin in self.packages.plugins:
			plugin._setIrc(self.connections[serverid])
			event = getattr(plugin, EVENT_MOTD, None)
			if callable(event):
				event(serverid,motd)

		# def motd_display(text,max,dolink,namecolor,foreground,background):
		motd = "<br>".join(motd)
		d = motd_display(motd,MAX_USERNAME_SIZE,True,self.display["system"],self.display["text"],self.display["background"])
		self.writeToLog(d)

	def ircerror(self,serverid,text):
		serverhost = self.connections[serverid].hostname
		if serverhost:
			d = systemTextDisplay(f"{serverhost}: {text}",self.display["system"],self.display["background"])
			self.printToActiveWindow(d)
			self.writeToLog(d)


	def setNewFont(self,font):
		f = QFont()
		f.fromString(font)

		self.app.setFont(f)
		self.logTxt.setFont(f)

		for c in self.connections:
			for w in self.windows[c]:
				w.window.channelChatDisplay.setFont(f)
				w.window.userTextInput.setFont(f)
				if w.window.is_channel:
					fb = f
					fb.setBold(True)
					w.window.channelUserDisplay.setFont(fb)

			fb = f
			fb.setBold(True)
			self.toolbars[c].stimer.setFont(fb)

		f = QFont()
		f.fromString(font)
		self.font = f
		self.font.setItalic(False)
		self.font.setBold(False)

		self.display["font"] = font
		saveDisplay(self.display)

		f = QFont()
		f.fromString(font)
		self.fontBold = f
		self.fontBold.setBold(True)
		self.fontBold.setItalic(False)

		f = QFont()
		f.fromString(font)
		self.fontitalic = f
		self.fontitalic.setItalic(True)
		self.fontitalic.setBold(False)

	def executeMenuClick(self,pclass):
		# Execute plugin events
		for plugin in self.packages.plugins:
			if plugin.name == pclass[0]:
				if plugin.version == pclass[1]:
					if plugin.description == pclass[2]:
						event = getattr(plugin, EVENT_MENU, None)
						if callable(event):
							event()


	def buildPluginMenu(self):
		self.pluginmenu.clear()

		# newEditorWindow
		actNewEdit = QAction(QIcon(EDIT_ICON),"Plugin Editor",self)
		actNewEdit.triggered.connect(self.newEditorWindow)
		self.pluginmenu.addAction(actNewEdit)

		self.pluginmenu.addSeparator()

		if len(self.packages.plugins)>0:

			pi = {}
			fi = {}
			for p in self.packages.plugins:
				if p._package in pi:
					file = p.__file__
					e = [p.name,p.version,p.description,file]
					pi[p._package].append(e)
					fi[p._package] = file
				else:
					pi[p._package] = []
					file = p.__file__
					e = [p.name,p.version,p.description,file]
					pi[p._package].append(e)
					fi[p._package] = file

			for key in pi:
				pmenu = self.pluginmenu.addMenu(QIcon(MODULE_ICON),key)
				pmenu.setToolTipsVisible(True)

				x = pmenu.addAction(QIcon(EDIT_ICON),"Edit")
				x.triggered.connect(lambda state,f=fi[key]: self.newEditorWindowFile(f))

				pmenu.addSeparator()

				x = pmenu.addAction("Included Plugins")
				f = x.font()
				f.setBold(True)
				f.setItalic(True)
				f.setUnderline(True)
				x.setFont(f)

				for qclass in pi[key]:
					pname = qclass[0]
					pversion = qclass[1]
					pdescription = qclass[2]
					x = pmenu.addAction(QIcon(PLUGIN_ICON),f"{pname} {pversion}")
					x.triggered.connect(lambda state,f=qclass: self.executeMenuClick(f))
					x.setToolTip(pdescription)
		else:

			actPlug = QAction(QIcon(BAN_ICON),"No plugins found",self)
			self.pluginmenu.addAction(actPlug)


	def newFindWindow(self,editobj):
		newEditSW = QMdiSubWindow()
		newEdit = FindWindow.Viewer(editobj)
		newEditSW.setWidget(newEdit)
		newEdit.subwindow = newEditSW
		self.MDI.addSubWindow(newEditSW)

		newEditSW.setWindowFlags(newEditSW.windowFlags() | Qt.CustomizeWindowHint)
		newEditSW.setWindowFlags(newEditSW.windowFlags() & ~Qt.WindowMinimizeButtonHint)
		newEditSW.setWindowFlags(newEditSW.windowFlags() & ~Qt.WindowMaximizeButtonHint)

		editobj.setFindWindow(newEditSW)
		newEdit.setSubwindow(newEditSW)

		if editobj.filename != "":
			f = os.path.basename(editobj.filename)
			newEditSW.setWindowTitle(f"Find in {f}")

		# Center window
		wx = (self.MDI.width()/2)-(newEditSW.width()/2)
		wy = (self.MDI.height()/2)-(newEditSW.height()/2)
		newEditSW.move(wx,wy)

		# No resize
		# This is also set in the __init__ of find window
		newEditSW.setFixedSize(newEditSW.sizeHint())

		newEditSW.show()

	def newEditorWindow(self):
		newEditSW = QMdiSubWindow()
		newEdit = EditorWindow.Viewer(None,self)
		newEditSW.setWidget(newEdit)
		newEdit.subwindow = newEditSW
		self.MDI.addSubWindow(newEditSW)

		newEditSW.resize(INITIAL_WINDOW_WIDTH,INITIAL_WINDOW_HEIGHT)

		newEditSW.show()

	def newEditorWindowFile(self,file):
		newEditSW = QMdiSubWindow()
		newEdit = EditorWindow.Viewer(file,self)
		newEditSW.setWidget(newEdit)
		newEdit.subwindow = newEditSW
		self.MDI.addSubWindow(newEditSW)

		newEditSW.resize(INITIAL_WINDOW_WIDTH,INITIAL_WINDOW_HEIGHT)

		newEditSW.show()

	def reloadPlugins(self):

		loaded = []

		for p in self.packages.plugins:
			e = p._package + p._class + p.name + p.version + p.description
			loaded.append(e)

		self.packages.reload_plugins()

		for p in self.packages.plugins:
			p._setGui(self)
			e = p._package + p._class + p.name + p.version + p.description
			if e in loaded: continue
			event = getattr(p, EVENT_LOAD, None)
			if callable(event):
				event()


		self.buildPluginMenu()
